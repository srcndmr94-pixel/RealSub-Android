package com.realsub.app

/**
 * Sadeleştirici.
 *
 * Cihaz üstü çeviri motoru düz bir makine çevirmenidir: deyimi, sokak ağzını
 * ve devrik İngilizceyi kelime kelime çevirip saçmalar. "off the grid" ona
 * "ızgara dışında" dedirtir, "he fucking knows" ona "o beceriyor" dedirtir.
 *
 * Bu yüzden İngilizce metin motora verilmeden önce burada üç aşamadan geçer:
 *   1. TAM KARŞILIK  — satırın tamamı sözlükte varsa makineye hiç gitmez,
 *                      doğru Türkçesi doğrudan basılır (hem anında hem kusursuz).
 *   2. SADELEŞTİRME  — deyimler ve sokak ağzı, makinenin doğru çevirdiği
 *                      yalın İngilizceye dönüştürülür.
 *   3. KÜFRÜ AYIRMA  — küfür vurgusu cümleden çıkarılır, Türkçe çevirinin
 *                      sonuna doğal biçimde geri eklenir ("Neredesin lan?").
 *      Küfür silinmiyor; sadece makinenin bozmayacağı yere taşınıyor.
 */
object Sade {

    class Sonuc(
        /** Satırın tamamının hazır karşılığı; doluysa çeviriye hiç gerek yok. */
        val tam: String?,
        /** Makineye verilecek yalın İngilizce. */
        val sade: String,
        /** Türkçe çevirinin sonuna eklenecek küfür vurgusu. */
        val ek: String,
        val kufurlu: Boolean,
        /** Sert küfür (fuck/shit/bitch...) — DeepL bunları yumuşattığı için ayrı tutulur. */
        val sert: Boolean = false
    )

    /** Satırın tamamı buysa makineye hiç gidilmez. 0/1/2/3 sertlik sırasıyla. */
    private val TAM: List<Pair<String, List<String>>> = listOf(
        "where the fuck you at" to listOf("neredesin", "neredesin", "nerelerdesin lan", "nerelerdesin amına koyayım"),
        "where you at" to listOf("neredesin", "neredesin", "nerelerdesin", "nerelerdesin"),
        "where the hell are you" to listOf("neredesin", "nerelerdesin", "nerelerdesin lan", "nerelerdesin amına koyayım"),
        "what you want" to listOf("ne istiyorsun", "ne istiyorsun", "ne istiyorsun", "ne istiyorsun"),
        "what do you want" to listOf("ne istiyorsun", "ne istiyorsun", "ne istiyorsun", "ne istiyorsun"),
        "what the fuck you want" to listOf("ne istiyorsun", "ne istiyorsun", "ne istiyorsun lan", "ne haltı istiyorsun amına koyayım"),
        "put it on speakerphone" to listOf("hoparlöre al", "hoparlöre al", "hoparlöre al", "hoparlöre al"),
        "pack it up" to listOf("toparlan", "topla şunları", "topla şunları", "topla şunları"),
        "pack that shit up" to listOf("toparlan", "topla şunları", "topla şu boku", "topla şu boku"),
        "hold up" to listOf("bekle", "dur bakalım", "dur", "dur"),
        "hold on" to listOf("bekle", "bir dakika", "dur bakalım", "dur"),
        "you feel me" to listOf("anlıyor musun", "anlıyor musun", "anladın mı beni", "anladın mı beni"),
        "you hear me" to listOf("duyuyor musun", "beni duyuyor musun", "duydun mu beni", "duydun mu beni"),
        "you know what i mean" to listOf("ne demek istediğimi anlıyor musun", "anlarsın ya", "anladın sen beni", "anladın sen beni"),
        "never heard of him" to listOf("onu hiç duymadım", "tanımıyorum", "tanımıyorum öyle birini", "tanımıyorum öyle birini"),
        "nah never heard of him" to listOf("hayır onu hiç duymadım", "yok tanımıyorum", "yok tanımıyorum", "yok tanımıyorum"),
        "what's up" to listOf("ne haber", "naber", "naber", "naber"),
        "what's going on" to listOf("neler oluyor", "ne oluyor", "ne oluyor", "ne haltlar dönüyor"),
        "what the fuck is going on" to listOf("neler oluyor", "ne oluyor böyle", "ne oluyor lan", "ne haltlar dönüyor amına koyayım"),
        "we good" to listOf("sorun yok", "aramız iyi", "sorun yok", "sorun yok"),
        "we're good" to listOf("sorun yok", "aramız iyi", "sorun yok", "sorun yok"),
        "i'm out" to listOf("ben gidiyorum", "ben kaçtım", "ben kaçtım", "ben kaçtım"),
        "let's go" to listOf("gidelim", "hadi gidelim", "hadi gidelim", "hadi gidelim"),
        "shut up" to listOf("sessiz ol", "sus", "kes sesini", "kapa çeneni"),
        "shut the fuck up" to listOf("sessiz ol", "kes sesini", "kapa çeneni lan", "kapa o lanet çeneni"),
        "my bad" to listOf("benim hatam", "kusura bakma", "benim hatam", "benim hatam"),
        "no doubt" to listOf("kesinlikle", "tabii ki", "tabii", "tabii"),
        "for real" to listOf("gerçekten", "cidden mi", "cidden mi", "cidden mi"),
        "are you serious" to listOf("ciddi misin", "ciddi misin", "ciddi misin", "ciddi misin"),
        "calm down" to listOf("sakin ol", "sakin ol", "sakin ol", "sakin ol"),
        "get out of here" to listOf("çık dışarı", "defol", "defol buradan", "defol buradan"),
        "come on" to listOf("hadi", "hadi ya", "hadi", "hadi"),
        "let me tell you something" to listOf("sana bir şey söyleyeyim", "bak sana bir şey diyeyim", "bak sana bir şey diyeyim", "bak sana bir şey diyeyim"),
        "i don't give a fuck" to listOf("umurumda değil", "hiç umurumda değil", "sikimde değil", "sikimde bile değil"),
        "i don't care" to listOf("umurumda değil", "umurumda değil", "hiç umurumda değil", "hiç umurumda değil"),
        "it's him" to listOf("bu o", "o arıyor", "o", "o"),
        "watch out" to listOf("dikkat", "dikkat et", "dikkat", "dikkat"),
        "look out" to listOf("dikkat", "dikkat et", "dikkat", "dikkat"),
        "what now" to listOf("şimdi ne olacak", "şimdi ne olacak", "ne olacak şimdi", "ne olacak şimdi"),
        "well shit" to listOf("eyvah", "hay aksi", "siktir", "hassiktir"),
        "everybody hands where we can see them" to listOf("herkes ellerini kaldırsın", "herkes ellerini görebileceğimiz yerde tutsun", "herkes elleri havaya", "herkes elleri havaya"),
        "hands where we can see them" to listOf("ellerini görebileceğimiz yerde tut", "ellerini görebileceğimiz yerde tut", "elleri havaya", "elleri havaya"),
        "hands up" to listOf("eller yukarı", "eller yukarı", "elleri havaya", "elleri havaya"),
        "it is him" to listOf("bu o", "o arıyor", "o", "o"),
        // Tek kelimelik ünlemler: vurgu ayıklanınca cümle boş kalmasın.
        "damn" to listOf("vay canına", "kahretsin", "hassiktir", "hassiktir"),
        "goddamn" to listOf("vay canına", "kahretsin", "hassiktir", "hay sikeyim"),
        "fuck" to listOf("kahretsin", "kahretsin", "siktir", "siktir lan"),
        "shit" to listOf("kahretsin", "kahretsin", "siktir", "siktir lan"),
        "holy shit" to listOf("vay canına", "inanmıyorum", "hassiktir", "hay sikeyim"),
        "fuck you" to listOf("canın cehenneme", "defol", "siktir git", "siktir git amına koyayım"),
        "fuck off" to listOf("git başımdan", "çek git", "siktir git", "siktir ol git"),
        "what the fuck" to listOf("bu da ne", "bu da ne böyle", "bu ne lan", "bu ne amına koyayım"),
        "yo what the fuck" to listOf("hey bu da ne", "hey bu da ne böyle", "hey bu ne lan", "hey bu ne amına koyayım"),
        "what the hell" to listOf("bu da ne", "bu da ne böyle", "bu ne ya", "bu ne be"),
        "no fucking way" to listOf("imkânsız", "asla", "yok artık lan", "yok amına koyayım"),
        "are you fucking kidding me" to listOf("şaka mı bu", "dalga mı geçiyorsun", "dalga mı geçiyorsun lan", "benimle dalga mı geçiyorsun amına koyayım"),
        "holy shit" to listOf("vay canına", "inanmıyorum", "hassiktir", "hay sikeyim")
    )

    /**
     * Sokak ağzı ve devrik İngilizce, makinenin doğru çevirdiği yalın
     * İngilizceye çevrilir. Sıra önemli: uzun kalıplar önce gelir.
     */
    private val SADELESTIR: List<Pair<String, String>> = listOf(
        // devrik dilbilgisi
        "ain't got no" to "do not have any",
        "ain't got" to "do not have",
        "ain't nobody" to "nobody",
        "ain't nothing" to "nothing",
        "he ain't come" to "he did not come",
        "she ain't come" to "she did not come",
        "they ain't come" to "they did not come",
        "you ain't ask" to "you did not ask",
        "i ain't ask" to "i did not ask",
        "you ain't" to "you are not",
        "he ain't" to "he is not",
        "she ain't" to "she is not",
        "they ain't" to "they are not",
        "we ain't" to "we are not",
        "it ain't" to "it is not",
        "i ain't" to "i am not",
        "ain't" to "is not",
        "he do not" to "he does not",
        "she do not" to "she does not",
        "it do not" to "it does not",
        "he don't" to "he does not",
        "she don't" to "she does not",
        "it don't" to "it does not",
        "where he at" to "where he is",
        "where she at" to "where she is",
        "where they at" to "where they are",
        "where you at" to "where you are",
        "what going on" to "what is going on",
        "what happening" to "what is happening",
        "who that" to "who is that",
        "that right" to "that is right",
        "problem is" to "the problem is",
        "he only worried" to "he is only worried",
        "she only worried" to "she is only worried",
        "he worried" to "he is worried",
        "they worried" to "they are worried",
        "we in a" to "we are in a",
        "we in" to "we are in",
        "you in" to "you are in",
        "he in" to "he is in",
        "imma" to "i am going to",
        "finna" to "about to",
        "gonna" to "going to",
        "wanna" to "want to",
        "gotta" to "have to",
        "kinda" to "kind of",
        "sorta" to "sort of",
        "outta" to "out of",
        "lemme" to "let me",
        "gimme" to "give me",
        "tryna" to "trying to",
        "y'all" to "you all",
        "yall" to "you all",

        // deyimler
        "don't give a fuck" to "do not care at all",
        "dont give a fuck" to "do not care at all",
        "don't give a shit" to "do not care at all",
        "give a fuck" to "care",
        "give a shit" to "care",
        "off the grid" to "unreachable",
        "snuck in" to "sneaked in",
        "watch out" to "be careful",
        "look out" to "be careful",
        "well shit" to "damn it",
        "look what the law chased in" to "look who the police brought in",
        "look what the cat dragged in" to "look who finally showed up",
        "snuck" to "sneaked",
        "we was" to "we were",
        "they was" to "they were",
        "you was" to "you were",
        "the law" to "the police",
        "feisty" to "aggressive",
        "cranked the speed up" to "increased the speed",
        "cranked up" to "turned up",
        "a buddy of mine" to "a friend of mine",
        "buddy of mine" to "friend of mine",
        "my buddy" to "my friend",
        "hold on to" to "keep holding",
        "getting harder to hold on" to "getting harder to keep holding",
        "street pushers" to "street dealers",
        "pushers" to "dealers",
        "pusher" to "dealer",
        "can't you handle" to "can you not deal with",
        "cant you handle" to "can you not deal with",
        "can you handle" to "can you deal with",
        "handle it" to "deal with it",
        "a bunch of" to "a group of",
        "it's him" to "it is him",
        "it's her" to "it is her",
        "that's him" to "that is him",
        "in a holding pattern" to "waiting",
        "holding pattern" to "waiting",
        "you feel me" to "you understand",
        "you dig" to "you understand",
        "you know what i mean" to "you understand",
        "pack that shit up" to "pack it up",
        "pack this shit up" to "pack it up",
        "that shit" to "that stuff",
        "this shit" to "this stuff",
        ", man" to ", friend",
        ", dawg" to ", friend",
        ", bro" to ", friend",
        "empty handed" to "with empty hands",
        "empty-handed" to "with empty hands",
        "hit me up" to "contact me",
        "hit you up" to "contact you",
        "come through" to "come over",
        "back in the day" to "in the past",
        "heads up" to "warning",
        "my word" to "my promise",
        "on god" to "i swear",
        "no cap" to "no lie",
        "deadass" to "seriously",
        "straight up" to "honestly",
        "run it back" to "do it again",
        "fall back" to "stay away",
        "check this out" to "look at this",
        "what's good" to "how are you",
        "what it is" to "how are you",
        "keep it real" to "be honest",
        "watch your back" to "be careful",
        "handle it" to "take care of it",
        "take care of it" to "deal with it",
        "set it up" to "arrange it",
        "lay low" to "stay hidden",
        "blow up" to "become famous",
        "tripping" to "overreacting",
        "trippin" to "overreacting",
        "snitch" to "informant",
        "snitching" to "informing",
        "the plug" to "the supplier",
        "racks" to "money",
        "bands" to "money",
        "a whip" to "a car",
        "the crib" to "the house",
        "my crib" to "my house",
        "strapped" to "armed",
        "jacked" to "stolen",
        "bounce" to "leave",
        "ride out" to "leave",
        "roll out" to "leave",
        "pull up" to "arrive",
        "slide through" to "come over",

        // hitaplar ve ünlemler
        "aight" to "all right",
        "a'ight" to "all right",
        "nah" to "no",
        "naw" to "no",
        "yep" to "yes",
        "yup" to "yes",
        "ay yo" to "hey",
        "yo" to "hey",
        "dawg" to "man",
        "homie" to "friend",
        "homies" to "friends",
        "bruh" to "man",
        "fam" to "friend",
        "cuz" to "friend",
        "boutta" to "about to",
        "'bout" to "about",
        "'em" to "them",
        "'cause" to "because"
    )

    /** Küfür vurgusu: cümleden çıkarılır, Türkçesi sona eklenir. */
    private val VURGU: List<String> = listOf(
        "what the fuck", "where the fuck", "who the fuck", "why the fuck", "how the fuck",
        "the fuck", "the hell", "as fuck", "as hell",
        // Cümle başındaki ünlem: "Fuck, it's him!" → "It's him!" + Türkçe vurgu.
        // Virgül/ünlem şartı var ki "give a fuck" kalıbı bozulmasın.
        "goddamn", "god damn", "motherfucking", "fucking", "fuckin'", "fuckin",
        "freaking", "frigging", "damn"
    )

    /**
     * Küfrün ŞİDDETİ ayrılır. Eskiden "what the hell" de "what the fuck" de
     * aynı eki alıyordu ve hafif bir replik "amına koyayım" ile bitiyordu.
     */
    private val SERT_KOK = Regex(
        "\\b(fuck\\w*|shit\\w*|bitch\\w*|cunt\\w*|motherfuck\\w*|asshole|" +
        "bastard|whore|slut|prick|piss\\w*|nigga)\\b", RegexOption.IGNORE_CASE)

    private val EKLER_SERT = arrayOf("", "", " lan", " amına koyayım")
    private val EKLER_HAFIF = arrayOf("", "", "", " ya")

    /**
     * Kelime sınırı yalnız harf/rakamla başlayıp biten kalıplara konur.
     * "'em" gibi kesme işaretiyle başlayan kalıpta \b hiç eşleşmez.
     */
    private fun sinirli(kalip: String): Regex {
        val bas = if (kalip.first().isLetterOrDigit()) "\\b" else ""
        val son = if (kalip.last().isLetterOrDigit()) "\\b" else ""
        return Regex(bas + Regex.escape(kalip) + son, RegexOption.IGNORE_CASE)
    }

    private fun temizle(s: String): String =
        s.lowercase()
            .replace(Regex("[\\.,!\\?;:\\\"'\\u2019\\u201c\\u201d\\-]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun buyut(s: String): String =
        if (s.isEmpty()) s else s.replaceFirstChar { it.uppercaseChar() }

    fun hazirla(en: String, hard: Int): Sonuc {
        val sertlik = hard.coerceIn(0, 3)
        val anahtar = temizle(en)
        if (anahtar.isEmpty()) return Sonuc(null, en, "", false, false)

        // 1) Satırın tamamı sözlükteyse makineye hiç gitme.
        for ((kalip, karsiliklar) in TAM) {
            if (anahtar == kalip) {
                val tr = karsiliklar[sertlik]
                val nokta = when {
                    en.trimEnd().endsWith("?") -> "?"
                    en.trimEnd().endsWith("!") -> "!"
                    else -> "."
                }
                return Sonuc(buyut(tr) + nokta, en, "", sertlik >= 2, SERT_KOK.containsMatchIn(en))
            }
        }

        // 2a) Cümle BAŞINDAKİ küfürlü ünlem ayrılır ("Fuck, it's him!").
        //     Yalnız başta: "shake some shit, know I'm saying" cümlesinde
        //     "shit," nesnedir, silinirse cümle bozuluyordu.
        var bastakiKufur = false
        var metin = en
        val basKalip = Regex("^\\s*(fuck|shit|damn|goddamn|christ|hell|crap|shoot)\\s*[,!\\.]+\\s*", RegexOption.IGNORE_CASE)
        if (basKalip.containsMatchIn(metin)) {
            val kalanMetin = basKalip.replace(metin, "")
            // Sadece ünlemden ibaretse ("Shit!") dokunma; TAM sözlüğü karşılar.
            if (kalanMetin.trim().length >= 3) { metin = kalanMetin; bastakiKufur = true }
        }

        // 2) Küfür vurgusunu ayır. Küfür silinmiyor; Türkçe tarafta sona eklenecek.
        var s = " " + metin + " "
        var kufurlu = bastakiKufur
        val sertKufur = SERT_KOK.containsMatchIn(en)
        for (v in VURGU) {
            val r = sinirli(v)
            if (r.containsMatchIn(s)) {
                kufurlu = true
                // "where the fuck" gibi soru kalıplarında soru kelimesi korunur.
                val yerine = when {
                    v.startsWith("what ") -> " what "
                    v.startsWith("where ") -> " where "
                    v.startsWith("who ") -> " who "
                    v.startsWith("why ") -> " why "
                    v.startsWith("how ") -> " how "
                    else -> " "
                }
                s = r.replace(s, yerine)
            }
        }

        // Vurgu çıkınca çift boşluk kalıyor; toparlanmazsa sonraki kalıplar
        // ("where he at" gibi) eşleşmiyor.
        s = s.replace(Regex("\\s+"), " ")

        // 2b) Küfür çıktıktan sonra geriye kalan kısım sözlükte olabilir:
        // "Fuck, it's him!" → "it's him" → hazır karşılığı var.
        if (kufurlu) {
            val kalan = temizle(s)
            for ((kalip, karsiliklar) in TAM) {
                if (kalan == kalip) {
                    val tr = karsiliklar[sertlik]
                    val nokta = when {
                        en.trimEnd().endsWith("?") -> "?"
                        en.trimEnd().endsWith("!") -> "!"
                        else -> "."
                    }
                    // Sözlük karşılığı zaten doğru sertlikte; üstüne vurgu eklenmez.
                    return Sonuc(buyut(tr) + nokta, en, "", true, sertKufur)
                }
            }
        }

        // 3) Sokak ağzını yalın İngilizceye çevir.
        for ((bul, yerine) in SADELESTIR) {
            if (!s.contains(bul, true)) continue
            s = sinirli(bul).replace(s, yerine)
        }

        s = s.replace(Regex("\\s+"), " ").trim()
        if (s.isEmpty()) s = en

        if (!kufurlu && Translator.kufurVar(en)) kufurlu = true
        val ek = when {
            !kufurlu -> ""
            sertKufur -> EKLER_SERT[sertlik]
            else -> EKLER_HAFIF[sertlik]
        }
        return Sonuc(null, buyut(s), ek, kufurlu, sertKufur)
    }

    /** Çeviriye küfür vurgusunu doğal biçimde geri ekler. */
    fun ekle(tr: String, ek: String): String {
        if (ek.isEmpty() || tr.isBlank()) return tr
        val t = tr.trimEnd()
        // "?!" gibi ÇOKLU noktalama tek karakter sanılıyordu ve küfür
        // cümlenin dışında kalıyordu: "Neler oluyor? amına koyayım!"
        val son = t.takeLastWhile { it == '.' || it == '?' || it == '!' }
        val govde = t.dropLast(son.length).trimEnd()
        if (govde.isEmpty()) return t
        return govde + ek + son
    }
}
