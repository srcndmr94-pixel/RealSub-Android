package com.realsub.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val REQ_PROJECTION = 1001
    private val REQ_NOTIF = 1002
    private val REQ_OPUS = 1004

    private lateinit var prefs: Prefs
    private lateinit var tvPerm: TextView
    private lateinit var tvRegion: TextView
    private lateinit var tvBottom: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        findViewById<TextView>(R.id.tvVersion).text = "sürüm " +
                (runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: "?") +
                " · 18.11.2026"

        tvPerm = findViewById(R.id.tvPerm)
        tvRegion = findViewById(R.id.tvRegion)
        tvBottom = findViewById(R.id.tvBottom)

        val etKey: EditText = findViewById(R.id.etKey)
        findViewById<Button>(R.id.btnOpus).setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            try { @Suppress("DEPRECATION") startActivityForResult(i, REQ_OPUS) }
            catch (e: Exception) { toast("Dosya seçici açılamadı.") }
        }

        val etIcerik: EditText = findViewById(R.id.etIcerik)
        etIcerik.setText(prefs.icerik)
        etIcerik.addTextChangedListener(saver { prefs.icerik = it })

        val etModel: EditText = findViewById(R.id.etModel)
        etKey.setText(prefs.apiKey)
        etModel.setText(prefs.model)
        etKey.addTextChangedListener(saver { prefs.apiKey = it })
        etModel.addTextChangedListener(saver { prefs.model = it })

        val cbAuto: CheckBox = findViewById(R.id.cbAuto)
        cbAuto.isChecked = prefs.autoRegion
        cbAuto.setOnCheckedChangeListener { _, v -> prefs.autoRegion = v; status() }

        val sbScan: SeekBar = findViewById(R.id.sbScan)
        sbScan.progress = ((prefs.scanFrom * 100).toInt() - 20).coerceIn(0, 65)
        sbScan.setOnSeekBarChangeListener(seek { prefs.scanFrom = (it + 20) / 100f; labels() })

        // --- çeviri sertliği ---
        val rg: RadioGroup = findViewById(R.id.rgHard)
        rg.check(when (prefs.hard) {
            0 -> R.id.rb0
            1 -> R.id.rb1
            3 -> R.id.rb3
            else -> R.id.rb2
        })
        rg.setOnCheckedChangeListener { _, id ->
            prefs.hard = when (id) {
                R.id.rb0 -> 0
                R.id.rb1 -> 1
                R.id.rb3 -> 3
                else -> 2
            }
        }

        // --- altyazı görünümü ---
        val rgSize: RadioGroup = findViewById(R.id.rgSize)
        rgSize.check(when (prefs.sizePreset) {
            0 -> R.id.rbS0
            2 -> R.id.rbS2
            3 -> R.id.rbS3
            else -> R.id.rbS1
        })
        rgSize.setOnCheckedChangeListener { _, id ->
            prefs.sizePreset = when (id) {
                R.id.rbS0 -> 0
                R.id.rbS2 -> 2
                R.id.rbS3 -> 3
                else -> 1
            }
        }

        val rgColor: RadioGroup = findViewById(R.id.rgColor)
        rgColor.check(if (prefs.textColor == "yellow") R.id.rbCy else R.id.rbCw)
        rgColor.setOnCheckedChangeListener { _, id ->
            prefs.textColor = if (id == R.id.rbCy) "yellow" else "white"
        }

        val rgPlace: RadioGroup = findViewById(R.id.rgPlace)
        rgPlace.check(when (prefs.placement) {
            "cover" -> R.id.rbPcover
            "fixed" -> R.id.rbPfixed
            else -> R.id.rbPabove
        })
        rgPlace.setOnCheckedChangeListener { _, id ->
            prefs.placement = when (id) {
                R.id.rbPcover -> "cover"
                R.id.rbPfixed -> "fixed"
                else -> "above"
            }
        }

        val sbBg: SeekBar = findViewById(R.id.sbBg)
        sbBg.progress = prefs.bgOpacity
        sbBg.setOnSeekBarChangeListener(seek { prefs.bgOpacity = it; labels() })

        val sbBottom: SeekBar = findViewById(R.id.sbBottom)
        sbBottom.progress = prefs.bottomPct
        sbBottom.setOnSeekBarChangeListener(seek { prefs.bottomPct = it; labels() })

        val cbBold: CheckBox = findViewById(R.id.cbBold)
        cbBold.isChecked = prefs.bold
        cbBold.setOnCheckedChangeListener { _, v -> prefs.bold = v }

        val cbEn: CheckBox = findViewById(R.id.cbEn)
        cbEn.isChecked = prefs.showEn
        cbEn.setOnCheckedChangeListener { _, v -> prefs.showEn = v }

        findViewById<Button>(R.id.btnTestSub).setOnClickListener { denemeAltyazisi() }
        findViewById<Button>(R.id.btnKayitPaylas).setOnClickListener {
            kayitBilgisi()
            val i = Kayit.paylas(this)
            if (i == null) toast("Kayıt boş.") else startActivity(Intent.createChooser(i, "Kaydı paylaş"))
        }
        findViewById<Button>(R.id.btnKayitKopyala).setOnClickListener {
            kayitBilgisi()
            val t = Kayit.metin()
            if (t.isEmpty()) { toast("Kayıt boş."); return@setOnClickListener }
            val cb = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cb.setPrimaryClip(android.content.ClipData.newPlainText("RealSub kaydı", t))
            toast("Kopyalandı — sohbete yapıştırabilirsin.")
        }
        // Gemma kaldırıldı: telefonda boşuna 2,4 GB tutuyordu. Dosya bizim
        // özel klasörümüzde ve artık hiçbir şey kullanmıyor, bir kez silinir.
        val eskiModel = prefs.modelPath
        if (eskiModel.isNotEmpty()) {
            Thread {
                val f = java.io.File(eskiModel)
                val mb = if (f.isFile) f.length() / 1024 / 1024 else 0L
                val silindi = try { !f.isFile || f.delete() } catch (e: Throwable) { false }
                prefs.modelPath = ""
                if (silindi && mb > 0) runOnUiThread { toast("Kullanılmayan eski model silindi ($mb MB yer açıldı).") }
            }.start()
        }

        findViewById<Button>(R.id.btnKayitTemizle).setOnClickListener {
            Kayit.temizle(); status(); toast("Kayıt temizlendi.")
        }
        labels()

        findViewById<Button>(R.id.btnOverlayPerm).setOnClickListener { askOverlay() }
        findViewById<Button>(R.id.btnRegion).setOnClickListener {
            if (!canOverlay()) { askOverlay(); return@setOnClickListener }
            startActivity(Intent(this, RegionActivity::class.java))
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener { start() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { stop() }
        findViewById<Button>(R.id.btnTest).setOnClickListener { testOnce() }
        findViewById<Button>(R.id.btnStatus).setOnClickListener { showStatus() }

        askNotif()
    }

    override fun onResume() {
        super.onResume()
        status()
    }

    private fun labels() {
        findViewById<TextView>(R.id.tvBg).text = "Zemin koyuluğu: %" + prefs.bgOpacity
        tvBottom.text = "Alttan uzaklık (sabit kipte): %" + prefs.bottomPct
        findViewById<TextView>(R.id.tvScan).text =
            "Taramanın başladığı yükseklik: %" + (prefs.scanFrom * 100).toInt()
    }

    /** Katmanın çalışıp çalışmadığını ekran kaydı olmadan görmek için. */
    private fun denemeAltyazisi() {
        if (!canOverlay()) { askOverlay(); return }
        val ov = Overlay(this, prefs)
        ov.anchorTop = 0
        ov.anchorBottom = 0
        ov.show()
        ov.set("Siktir git, bu işte yokum.", "Screw you, I'm out.")
        android.os.Handler(mainLooper).postDelayed({ ov.hide() }, 6000)
        toast("6 saniye boyunca ekranda duracak.")
    }

    private fun status() {
        tvPerm.text = if (canOverlay())
            "Ekranın üstüne çizme izni verilmiş."
        else
            "Ekranın üstüne çizme izni gerekiyor — altyazı bu izinle görünür."

        Kayit.basla(applicationContext)
        findViewById<TextView>(R.id.tvKayit).text =
            Kayit.sayi.toString() + " replik kaydedildi. Altyazı dosyası olarak paylaşabilirsin."
        val sonlar = Kayit.sonlar(3)
        findViewById<TextView>(R.id.tvKayitSon).text =
            if (sonlar.isEmpty()) "—"
            else sonlar.joinToString("\n\n") { it.tr + "\n" + it.en }

        findViewById<TextView>(R.id.tvOpus).text = when {
            Opus.ready -> "Hazır. Çeviri telefonda, internetsiz yapılıyor — en hızlı yol bu."
            OpusModelPack.isInstalled(this) -> "Model yüklü: " + Opus.durum + ". Başlat'a basınca açılacak."
            else -> "Model yok. Depoda Actions > 'OPUS-MT model paketi' işini çalıştır, inen zip'i burada göster."
        }




        tvRegion.text = if (prefs.autoRegion)
            "Program ekranın alt yarısını tarar, altyazıyı kendisi bulur. Elle alan seçmen gerekmez."
        else {
            val land = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels
            if (prefs.regionSet(land))
                "Elle seçili alan (" + (if (land) "yatay" else "dikey") + "): üstten %" +
                        (prefs.regionT(land) * 100).toInt() + ", genişlik %" +
                        ((prefs.regionR(land) - prefs.regionL(land)) * 100).toInt()
            else "Elle kip açık ama alan seçilmedi — aşağıdaki düğmeyle seç."
        }
    }

    private fun canOverlay(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun askOverlay() {
        if (canOverlay()) { toast("İzin zaten verilmiş."); return }
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    private fun start() {
        if (!canOverlay()) { askOverlay(); return }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    private fun stop() {
        val i = Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)
        startService(i)
        toast("Durduruldu.")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(req, res, data)
        if (req == REQ_OPUS) {
            val uri = data?.data
            if (res != Activity.RESULT_OK || uri == null) { toast("Dosya seçilmedi."); return }
            toast("Model yükleniyor, bekle...")
            Thread {
                val hata = OpusModelPack.import(applicationContext, uri)
                if (hata == null) Opus.hazirla(applicationContext)
                runOnUiThread {
                    toast(hata ?: "OPUS-MT modeli yüklendi.")
                    status()
                }
            }.start()
            return
        }
        if (req != REQ_PROJECTION) return
        if (res != Activity.RESULT_OK || data == null) { toast("Ekran izni verilmedi."); return }

        val i = Intent(this, CaptureService::class.java)
            .setAction(CaptureService.ACTION_START)
            .putExtra(CaptureService.EXTRA_CODE, res)
            .putExtra(CaptureService.EXTRA_DATA, data)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)

        toast("Başladı — uygulamadan çıkıp izlemeye başla.")
        moveTaskToBack(true)
    }

    /** Çalışırken tek kare okutur; değişim beklemeden okur. */
    private fun testOnce() {
        if (!CaptureService.running) { toast("Önce Başlat'a bas."); return }
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_TEST))
        toast("Okunuyor — 2 saniye sonra Durumu yenile.")
    }

    /**
     * Kaydın başına sürüm ve ayar özeti yazar. Kayıt tek başına hangi sürümle
     * ve hangi ayarla alındığını söylemiyordu; sorun ararken bu bilgi şart.
     */
    private fun kayitBilgisi() {
        val sv = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: "?"
        val sb = StringBuilder()
        sb.append("sürüm ").append(sv)
        sb.append(" · sertlik ").append(prefs.hard)
        sb.append(" · model ").append(if (prefs.apiKey.isEmpty()) "anahtar yok" else prefs.model)
        sb.append(" · OPUS ").append(if (Opus.ready) "hazır" else Opus.durum)
        if (Opus.sonHata.isNotEmpty()) sb.append(" [çeviri hatası: ").append(Opus.sonHata).append("]")
        if (CaptureService.aiDeneme > 0 || CaptureService.aiAtlandi > 0) {
            sb.append(" · yapay zekâ ").append(CaptureService.aiDeneme).append(" deneme / ")
                .append(CaptureService.aiHata).append(" hata / ")
                .append(CaptureService.aiAtlandi).append(" atlandı")
        }
        if (CaptureService.sonAiHata.isNotEmpty())
            sb.append("\nson yapay zekâ hatası: ").append(CaptureService.sonAiHata)
        // Zincirin nerede koptuğu kayıttan görünsün; ayrıca sormaya gerek kalmasın.
        sb.append("\nkare ").append(CaptureService.frames)
            .append(" · değişim ").append(CaptureService.changes)
            .append(" · okuma ").append(CaptureService.reads)
            .append(" · çeviri ").append(CaptureService.translations)
        val eleme = Ocr.elemeOzeti()
        if (eleme.isNotEmpty()) sb.append("\neleme: ").append(eleme)
        if (Ocr.lastReason.isNotEmpty())
            sb.append("\nson eleme sebebi: ").append(Ocr.lastReason)
                .append(if (Ocr.lastRaw.isNotEmpty()) " — " + Ocr.lastRaw.take(60) else "")
        Kayit.bilgi = sb.toString()
    }

    /** Akışın neresinde takıldığını gösterir. */
    private fun showStatus() {
        val tv: TextView = findViewById(R.id.tvStatus)
        if (!CaptureService.running) { tv.text = "Çalışmıyor. Başlat'a bas."; return }
        val b = StringBuilder()
        b.append("Alınan kare: ").append(CaptureService.frames).append("\n")
        b.append("Ekran yeniden kuruldu: ").append(CaptureService.rotations).append(" kez\n")
        b.append("Algılanan değişim: ").append(CaptureService.changes).append("\n")
        b.append("Seçili alandaki parlak nokta: ").append(CaptureService.lastBright).append("\n")
        b.append("Okuma denemesi: ").append(CaptureService.reads).append("\n")
        b.append("Çeviri: ").append(CaptureService.translations).append("\n\n")
        b.append("Son okunan: ").append(CaptureService.lastOcr.ifEmpty { "—" }).append("\n")
        b.append("Son çeviri: ").append(CaptureService.lastTr.ifEmpty { "—" })
        b.append("\nÇeviren: ").append(CaptureService.lastEngine.ifEmpty { "—" })
        if (CaptureService.aiNot.isNotEmpty())
            b.append("\nYapay zekâ: ").append(CaptureService.aiNot)
        if (CaptureService.aiDeneme > 0 || CaptureService.aiAtlandi > 0)
            b.append("\nYapay zekâ sayacı: ").append(CaptureService.aiDeneme).append(" deneme, ")
                .append(CaptureService.aiHata).append(" hata, ")
                .append(CaptureService.aiAtlandi).append(" atlandı")
        if (CaptureService.sonAiHata.isNotEmpty())
            b.append("\nSon yapay zekâ hatası: ").append(CaptureService.sonAiHata)
        if (CaptureService.lastError.isNotEmpty()) b.append("\n\nSon hata: ").append(CaptureService.lastError)
        tv.text = b.toString()
    }

    /** Model dosyasını seçtirir; seçilen dosya uygulamanın kendi alanına kopyalanır. */
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun saver(f: (String) -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    }

    private fun seek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) { f(v) }
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }
}
