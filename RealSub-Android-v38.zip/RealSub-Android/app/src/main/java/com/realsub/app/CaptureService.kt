package com.realsub.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast

/**
 * Ekranı kaydeder, seçili alandaki altyazıyı okur, çevirir ve katmanda gösterir.
 * İstek yalnızca altyazı değiştiğinde gönderilir.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_TEST = "test"
        private const val CHANNEL = "realsub"
        private const val NOTIF_ID = 41
        @Volatile var running = false

        /** Durum ekranı için sayaçlar — aynı süreçte olduğumuz için doğrudan okunur. */
        @Volatile var frames = 0
        @Volatile var changes = 0
        @Volatile var reads = 0
        @Volatile var translations = 0
        @Volatile var lastOcr = ""
        @Volatile var lastTr = ""
        @Volatile var lastError = ""
        @Volatile var lastBright = 0
        @Volatile var forceOnce = false
        @Volatile var rotations = 0
        @Volatile var lastEngine = ""
        /** Yapay zekânın neden susduğu; durum ekranında gösterilir. */
        @Volatile var aiNot = ""
        // Hata kaydı replik değişince kayboluyordu; sayaçlar süreç boyunca durur.
        @Volatile var aiDeneme = 0
        @Volatile var aiHata = 0
        @Volatile var aiAtlandi = 0
        @Volatile var sonAiHata = ""

        fun resetStats() {
            frames = 0; changes = 0; reads = 0; translations = 0; rotations = 0
            lastOcr = ""; lastTr = ""; lastError = ""; lastBright = 0; lastEngine = ""; aiNot = ""
            try { Ocr.elemeSifirla() } catch (e: Throwable) { }
            try { Ocr.kaliciSifirla() } catch (e: Throwable) { }
            aiDeneme = 0; aiHata = 0; aiAtlandi = 0; sonAiHata = ""
        }
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    private lateinit var prefs: Prefs
    private var overlay: Overlay? = null

    private var worker: HandlerThread? = null
    private var workHandler: Handler? = null
    private val main = Handler(Looper.getMainLooper())

    private var sw = 0
    private var sh = 0
    private var lastSig: IntArray? = null
    private var changed = false
    private var quiet = 0
    private var lastText = ""
    private var prevText = ""
    private var busy = false
    private var failUntil = 0L
    private var lastToastAt = 0L
    private var cropTop = 0
    private var missCount = 0
    private var blackFrames = 0
    private var displayCreated = false
    /** Altyazının bulunduğu şerit (kırpılmış görüntüdeki dikey orta nokta). */
    private var band = -1f
    private var bandMiss = 0
    private var lastCropH = 0
    /** Yapay zekâ düzeltmesi geciktiğinde eski repliğin ekrana yazılmasını engeller. */
    @Volatile private var showToken = 0L
    // Çeviri iş parçacıkları. DİKKAT: bunlar bir kez kapatılınca bir daha
    // açılmaz ve her çeviri isteği sessizce reddedilir. Durdur/Başlat
    // döngüsünde servis aynı örnek üzerinden devam edebildiği için
    // başlangıçta kapalı olanlar yeniden kurulur.
    private var refiner = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var hizli = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var anlik = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun isParcaciklariniHazirla() {
        if (refiner.isShutdown) refiner = java.util.concurrent.Executors.newSingleThreadExecutor()
        if (hizli.isShutdown) hizli = java.util.concurrent.Executors.newSingleThreadExecutor()
        if (anlik.isShutdown) anlik = java.util.concurrent.Executors.newSingleThreadExecutor()
    }

    /** İstek reddedilirse sessiz kalmasın; durum ekranında ve kayıtta görünsün. */
    private fun calistir(e: java.util.concurrent.ExecutorService, is_: Runnable) {
        try { e.execute(is_) } catch (x: Throwable) {
            lastError = "çeviri iş parçacığı reddetti: " + (x.javaClass.simpleName)
            note("çeviri başlatılamadı — Durdur / Başlat")
        }
    }

    // --- Yapay zekâ kota yönetimi ---------------------------------------
    // Ücretsiz katmanda dakika ve gün başına istek sınırı var. Her repliği
    // göndermek sınırı bir dakikada bitiriyor ve sonrasında her satır
    // "kota doldu" dönüyordu. Burada istek hızı tutuluyor, kota dolunca da
    // bir süre hiç istek atılmıyor ki pencere kendini toparlasın.
    private val aiIstekler = java.util.ArrayDeque<Long>()
    @Volatile private var aiBeklemeSonu = 0L

    private val gecmis = ArrayList<String>()
    private val sonMetinler = ArrayList<Pair<String, Long>>()

    /** Son 8 saniyede bu replik çevrildi mi? */
    private fun yakindaCevrildi(t: String): Boolean {
        val now = System.currentTimeMillis()
        synchronized(sonMetinler) {
            sonMetinler.removeAll { now - it.second > 8000L }
            for ((m, _) in sonMetinler) if (Ocr.similar(t, m) > 0.85f) return true
            sonMetinler.add(Pair(t, now))
            if (sonMetinler.size > 6) sonMetinler.removeAt(0)
            return false
        }
    }

    private fun aiIzin(): Boolean {
        val now = System.currentTimeMillis()
        if (now < aiBeklemeSonu) {
            aiNot = "kota doldu, " + ((aiBeklemeSonu - now) / 1000) + " sn bekleniyor"
            return false
        }
        synchronized(aiIstekler) {
            while (aiIstekler.isNotEmpty() && now - aiIstekler.peekFirst() > 60000L) aiIstekler.pollFirst()
            // Sınır 9'du ve dakikada 16 replik gelen sahnelerde repliklerin
            // çoğu yapay zekâya hiç gitmiyordu (23 denemede 20 atlandı).
            // Kota hatası değil, benim sınırım engelliyordu; 15'e çıkarıldı.
            // Gerçekten kota dolarsa 429 yakalanıp 90 sn beklemeye geçiliyor.
            if (aiIstekler.size >= 15) {
                aiNot = "dakikalık sınır dolu, çeviri çevrimdışı motordan"
                return false
            }
            aiIstekler.addLast(now)
            aiNot = "çalışıyor (son dakikada " + aiIstekler.size + " istek)"
            return true
        }
    }

    /**
     * Her replik yapay zekâya gitmez. İsimler, tek kelimelik ünlemler ve
     * sözlükten tam karşılığı gelmiş satırlar zaten doğru; onlara istek
     * harcamak günlük kotayı boşuna bitiriyor.
     */
    private fun aiGerekli(en: String, hazir: Sade.Sonuc): Boolean {
        if (hazir.tam != null) return false
        val k = en.trim()
        // Eşik gevşetildi: "Appreciate it." gibi kısa replikler de yapay zekâya
        // gitsin ("Minnettarım" yerine "Sağ ol").
        if (k.length < 8 && !hazir.kufurlu) return false
        if (k.split(Regex("\\s+")).size < 2 && !hazir.kufurlu) return false
        return true
    }
    private val kilit = Any()
    @Volatile private var gosterimAni = 0L
    @Volatile private var okumaAni = 0L
    /** Yapay zekâya tanınan süre; yetişmezse yerel çeviri basılır. */
    private val AI_BEKLEME = 1200L
    @Volatile private var ekranKilitli = false
    @Volatile private var capaUst = 0
    @Volatile private var capaAlt = 0
    @Volatile private var sonBulunanAn = 0L
    @Volatile private var zincir = ""
    @Volatile private var gosterilenKalite = 0
    @Volatile private var kayitSira = -1

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        prefs = Prefs(this)

        if (intent?.action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_TEST) {
            forceOnce = true
            return START_STICKY
        }

        startForeground(NOTIF_ID, buildNotification())

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)

        if (code == 0 || data == null) {
            toast("Ekran izni alınamadı.")
            stopEverything()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (p == null) {
            toast("Ekran kaydı başlatılamadı.")
            stopEverything()
            return START_NOT_STICKY
        }
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopEverything() }
            }
        }, main)

        resetStats()
        band = -1f; bandMiss = 0; lastCropH = 0
        Ocr.forgetDisplayed()
        Kayit.basla(applicationContext)
        // Telefondaki model varsa arka planda yüklenir; ilk replikte hazır olur.
        val mp = prefs.modelPath
        if (prefs.useLocal && mp.isNotEmpty()) Thread { LocalModel.ensure(applicationContext, mp) }.start()
        startCapture()
        running = true
        return START_STICKY
    }

    // ------------------------------------------------------------ ekran kaydı
    /** Ekranın o anki gerçek ölçüsü. Telefon döndüğünde en ve boy yer değiştirir. */
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun densityDpi(): Int {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return dm.densityDpi
    }

    private fun startCapture() {
        isParcaciklariniHazirla()
        worker = HandlerThread("realsub-loop").also { it.start() }
        workHandler = Handler(worker!!.looper)
        buildDisplay()
        overlay = Overlay(this, prefs).also { main.post { it.show() } }
        workHandler?.post(bekci)
        // Isınma: ilk replik el sıkışmasını beklemesin, çevrimdışı model hazırlansın.
        // Model hazırlama ÇEVİRİ İŞ PARÇACIĞINDA yapılmamalı: ONNX oturumunu
        // açmak saniyeler sürüyor ve o süre boyunca ilk replikler kuyrukta
        // bekliyordu. Ayrı bir iş parçacığında yapılır.
        Thread {
            try { Opus.hazirla(applicationContext) } catch (e: Throwable) { }
        }.start()
        calistir(hizli) {
            try { Translator.isit(prefs.apiKey) } catch (e: Throwable) { }
        }
    }

    /**
     * Sanal ekranı kurar ya da ölçüsünü günceller.
     *
     * ÖNEMLİ: Android aynı yakalama izniyle İKİNCİ bir sanal ekran kurdurtmuyor;
     * denenirse yakalama tamamen ölüyor ("kayıt kendi kendine kapanıyor").
     * Bu yüzden sanal ekran izin başına bir kez kurulur, ekran dönünce
     * bırakılıp yeniden kurulmaz, yalnızca boyutlandırılır.
     */
    @Synchronized
    private fun buildDisplay() {
        val (w, h) = screenSize()
        if (w <= 0 || h <= 0) return
        if (displayCreated && w == sw && h == sh) return

        val yeniReader = try {
            ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        } catch (e: Throwable) {
            lastError = "görüntü okuyucu kurulamadı"
            return
        }

        try {
            if (!displayCreated) {
                val vd = projection?.createVirtualDisplay(
                    "RealSub", w, h, densityDpi(),
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    yeniReader.surface, null, null
                )
                if (vd == null) {
                    yeniReader.close()
                    lastError = "sanal ekran kurulamadı"
                    return
                }
                display = vd
                displayCreated = true
            } else {
                val vd = display
                if (vd == null) { yeniReader.close(); return }
                // Sıra önemli: önce yüzeyi ayır, sonra boyutla, sonra yeni yüzeyi bağla.
                vd.setSurface(null)
                vd.resize(w, h, densityDpi())
                vd.setSurface(yeniReader.surface)
            }
        } catch (e: Throwable) {
            try { yeniReader.close() } catch (x: Throwable) { }
            lastError = "ekran kurulumu: " + (e.message ?: e.javaClass.simpleName).take(90)
            return
        }

        try { dinleyiciBirak() } catch (e: Throwable) { }
        val eski = reader
        reader = yeniReader
        // Kareler artık bu dinleyiciye düşer; yoklama yapılmaz.
        try { yeniReader.setOnImageAvailableListener(kareGeldi, workHandler) } catch (e: Throwable) { }
        try { eski?.close() } catch (e: Throwable) { }

        sw = w
        sh = h
        lastSig = null
        capaUst = 0
        capaAlt = 0
        band = -1f
        bandMiss = 0
        lastCropH = 0
    }

    /** Eski okuyucunun dinleyicisi bırakılır; kapanan okuyucu kare göndermesin. */
    private fun dinleyiciBirak() {
        try { reader?.setOnImageAvailableListener(null, null) } catch (e: Throwable) { }
    }

    @Volatile private var sonKare = 0L
    @Volatile private var sonOkuma = 0L
    @Volatile private var buyukDegisim = false

    /**
     * Kare geldiği AN çalışır; yoklama yok.
     *
     * Eskiden 220 ms'de bir bakılıyordu, yani bir replik ekrana düştükten sonra
     * en kötü durumda 220 ms kimse farkına varmıyordu. Android ekran değiştiğinde
     * kendiliğinden kare üretir; artık o kare düştüğü an işleniyor. 60 fps'lik
     * bir oyun işlemciyi yemesin diye kareler arasına en az 40 ms konur.
     */
    private val kareGeldi = object : ImageReader.OnImageAvailableListener {
        override fun onImageAvailable(r: ImageReader) {
            val now = System.currentTimeMillis()
            if (busy || now - sonKare < 40) {
                // Atılan kare KAPATILMAZSA üretici tıkanır ve yakalama durur.
                try { r.acquireLatestImage()?.close() } catch (e: Throwable) { }
                return
            }
            sonKare = now
            try { tick() } catch (e: Exception) { }
        }
    }

    /**
     * Güvenlik ağı: bazı cihazlarda dinleyici hiç tetiklenmiyor ya da ekran
     * donduğu için kare üretilmiyor. Bekçi 600 ms'de bir yoklar, böylece en
     * kötü durumda uygulama eski hızında yine çalışır.
     */
    private val bekci = object : Runnable {
        override fun run() {
            try {
                if (System.currentTimeMillis() - sonKare > 600) {
                    sonKare = System.currentTimeMillis()
                    tick()
                }
            } catch (e: Exception) { }
            workHandler?.postDelayed(this, 600)
        }
    }

    private fun tick() {
        // Telefon döndüyse sanal ekran yeni ölçüyle yeniden kurulur.
        val (cw, ch) = screenSize()
        if (cw != sw || ch != sh) {
            rotations++
            buildDisplay()
            return
        }
        if (busy || System.currentTimeMillis() < failUntil) return

        // ALTYAZI EKRANDAN GİDİNCE ÇEVİRİ DE GİTSİN.
        // "Boş ekran" testi yalnız parlaklığa bakıyordu ve renkli/aydınlık
        // sahnede hiç tetiklenmiyordu; çeviri ekranda asılı kalıyordu.
        // Artık belli bir süre altyazı bulunamazsa yazı kaldırılır.
        val simdiKontrol = System.currentTimeMillis()
        if (lastTr.isNotEmpty() && sonBulunanAn > 0L && simdiKontrol - sonBulunanAn > 2500L) {
            lastTr = ""
            lastText = ""
            post("", "")
        }
        val img = reader?.acquireLatestImage() ?: return
        val crop: Bitmap? = try { cropRegion(img) } finally { img.close() }
        if (crop == null) return

        frames++
        val sig = signature(crop)
        lastBright = sig[sig.size - 1]

        // Korumalı uygulama (Netflix vb.) kareyi tamamen siyah verir.
        var mn = 255
        var mx = 0
        for (i in 0 until sig.size - 1) { if (sig[i] < mn) mn = sig[i]; if (sig[i] > mx) mx = sig[i] }
        if (mx - mn < 6) {
            blackFrames++
            if (blackFrames == 8) note("ekran korumalı — bu uygulama paylaşımı engelliyor")
            if (blackFrames >= 8) { serbest(crop); return }
        } else blackFrames = 0
        val blank = lastBright < (sig.size - 1) * 0.0015   // yazı yok
        val prev = lastSig
        if (prev != null) {
            val d = diff(sig, prev)
            // Otomatik kipte geniş alan taranır; oyundaki ışık/patlama boşuna tetiklemesin.
            val esik = if (prefs.autoRegion) 14 else 8
            if (d > esik) {
                changed = true
                changes++
                // Değişim büyükse replik tamamen değişmiştir, AYNI KAREDE okunur.
                // (v19'da buraya "yazı otursun" diye bekleme koymuştum; okunan
                // replik sayısı 15-18'den 3-4'e düştü. Bekleme kaldırıldı:
                // ara sıra bir harfi yanlış okumak, repliği hiç yakalamamaktan
                // çok daha iyi.)
                val buyuk = d > esik * 3
                if (buyuk) buyukDegisim = true
                quiet = if (buyuk) 1 else 0
            } else if (changed) quiet++
        }
        lastSig = sig

        val force = forceOnce
        if (force) forceOnce = false

        if (blank && !force) {
            if (changed && quiet >= 1) {
                changed = false
                lastText = ""
                post("", "")
            }
            serbest(crop)
            return
        }
        if (!force && (!changed || quiet < 1)) { serbest(crop); return }
        // Oyunda arka plan sürekli oynadığı için değişim bitmez. Yeni replik
        // (büyük değişim) hemen okunur; küçük oynamalarda okuma 90 ms'den sık
        // yapılmaz, yoksa telefon boşuna ısınır ve oyun takılır.
        val simdi = System.currentTimeMillis()
        if (!force && !buyukDegisim && simdi - sonOkuma < 90) { serbest(crop); return }
        sonOkuma = simdi
        buyukDegisim = false
        changed = false

        busy = true
        try {
            if (crop.height != lastCropH) { lastCropH = crop.height; band = -1f }
            val tol = crop.height * 0.13f
            var found = Ocr.detect(crop, prefs.autoRegion, band, tol)
            if (found == null && band >= 0f) {
                // Şeritte bir şey yok: birkaç denemeden sonra şerit serbest bırakılır.
                bandMiss++
                // Şerit 5 okuma boyunca tutuluyordu; altyazı biraz farklı
                // yükseklikte çıkınca o süre boyunca replik kaybediliyordu.
                if (bandMiss >= 2) { band = -1f; bandMiss = 0; found = Ocr.detect(crop, prefs.autoRegion) }
            }
            reads++
            if (found == null) {
                val sebep = Ocr.lastReason
                lastOcr = if (Ocr.lastRaw.isNotEmpty()) "(elendi) " + Ocr.lastRaw else "(" + sebep + ")"
                missCount++
                if (missCount >= 7) {
                    lastText = ""
                    // EKRANA BASILMAZ. Bu notlar hata ayıklama içindi ve
                    // altyazının yerine "RealSub: yazı çok küçük: ..." diye
                    // çıkıyordu. Sebep artık yalnız durum ekranında ve
                    // çalışma kaydının başlığında görünür.
                }
                return
            }
            missCount = 0
            bandMiss = 0
            sonBulunanAn = System.currentTimeMillis()
            // Yapışık kelimeler çeviriye gitmeden ayrılır ("Itold" → "I told").
            val text = Ocr.temizleOkuma(found.text)
            lastOcr = text
            // Altyazının şeridi öğrenilir; sonraki karelerde arayüz yazıları elenir.
            band = if (band < 0f) (found.top + found.bottom) / 2f
                   else band * 0.75f + ((found.top + found.bottom) / 2f) * 0.25f
            // Bulunan altyazının ekrandaki yeri: çeviri bunun üstüne yerleşir.
            // ALTYAZI YERİ SABİTLENİR.
            // Çapa her okumada yeniden kuruluyordu; OCR kutusu birkaç piksel
            // oynayınca Türkçe yazı ekranda zıplıyordu ("dans ediyor").
            // Artık yer yumuşatılmış ortalamayla tutulur ve ancak kayda değer
            // bir oynama olursa (ekran yüksekliğinin %2'si) güncellenir.
            val yeniUst = cropTop + found.top
            val yeniAlt = cropTop + found.bottom
            val esikPx = maxOf(12, (sh * 0.02f).toInt())
            if (capaUst <= 0 || Math.abs(yeniUst - capaUst) > esikPx) {
                capaUst = yeniUst
                capaAlt = yeniAlt
            } else if (Math.abs(yeniUst - capaUst) > 8) {
                // Ölü bölge: 8 pikselden küçük oynamada yazı HİÇ kıpırdamaz.
                // Ölçüm: ham OCR 236 px zıplıyordu, bu ayarla 53 px'e iniyor
                // ve kalanın neredeyse tamamı altyazının gerçekten yer
                // değiştirdiği an (tek satırdan iki satıra çıkması).
                capaUst = (capaUst * 7 + yeniUst) / 8
                capaAlt = (capaAlt * 7 + yeniAlt) / 8
            }
            overlay?.anchorTop = capaUst
            overlay?.anchorBottom = capaAlt
            if (!force && Ocr.similar(text, lastText) > 0.85f) return
            // Altyazı bir an kaybolup aynen geri geldiğinde (ya da bir harfi
            // yanlış okunduğunda) baştan çevriliyordu: aynı replik üç kez
            // çevrilip üç kez kota harcıyordu.
            if (!force && yakindaCevrildi(text)) return
            lastText = text
            okumaAni = System.currentTimeMillis()
            val token = ++showToken
            gosterilenKalite = 0
            gosterimAni = 0L
            ekranKilitli = false
            zincir = ""
            kayitSira = -1
            // Araştırma: 4 önceki replik bağlam olarak verildiğinde çeviri
            // kalitesi belirgin artıyor. Önceden yalnız 1 replik gönderiliyordu.
            val onceki = synchronized(gecmis) {
                val k = gecmis.joinToString("\n")
                gecmis.add(text)
                while (gecmis.size > 4) gecmis.removeAt(0)
                k
            }
            prevText = text
            val key = prefs.apiKey

            // İKİ KADEME.
            //  1) Cihaz üstü motor: anında basar (OPUS-MT, yoksa ML Kit,
            //     ikisi de olmazsa ağ). Hangisi iş görürse o basar; biri
            //     boş dönerse SIRADAKİNE geçilir, ekran boş kalmaz.
            //  2) Yapay zekâ: bağlamı ve önceki replikleri görür, gelince
            //     birincinin yerine geçer.

            // Metin makineye verilmeden sadeleştirilir: deyim ve sokak ağzı
            // yalın İngilizceye çevrilir, küfür ayrılıp Türkçe tarafta sona
            // eklenir. Sözlükte tam karşılığı varsa makineye hiç gidilmez.
            val hazir = Sade.hazirla(text, prefs.hard)

            // TEK SEFERDE BASMA.
            // Yapay zekânın GERÇEKTEN çağrılıp çağrılmayacağı burada, kademe
            // 1'den ÖNCE belirlenir. (Dakika sınırına takılırsa çağrılmaz ve
            // altyazı boşuna beklememeli.) Çağrılacaksa telefondaki motorun
            // çevirisi hemen basılmaz; yapay zekâ yetişirse altyazı bir kez
            // yazılır ve hiç değişmez.
            val aiIstenir = key.isNotEmpty() && aiGerekli(text, hazir)
            val aiCalisacak = aiIstenir && aiIzin()
            if (aiIstenir && !aiCalisacak) aiAtlandi++

            calistir(anlik) {
                // Cümle yarım bittiyse (virgül, bağlaç) kısa bir bekleme:
                // devamı aynı replikte geliyorsa tamamını çevirelim.
                val b = Bekleme.ms(text)
                if (b > 0) try { Thread.sleep(b) } catch (e: InterruptedException) { }

                fun bicimle(ham: String): String =
                    if (ham.isBlank()) ""
                    else Sade.ekle(Translator.sertlestir(ham, prefs.hard), hazir.ek)

                var d = ""
                var motor1 = ""
                val tam = hazir.tam
                if (tam != null) {
                    d = tam
                    motor1 = "sözlük"
                } else {
                    // YEDEKLEME ZİNCİRİ: biri boş dönerse ötekine geçilir.
                    // Eskiden OPUS boş dönünce replik hiç çevrilmiyordu.
                    if (Opus.ready) {
                        d = try { bicimle(Opus.translate(hazir.sade)) } catch (e: Throwable) { "" }
                        if (d.isNotEmpty()) motor1 = "OPUS-MT"
                    }
                    if (d.isEmpty()) {
                        d = try { bicimle(Translator.fast(hazir.sade, prefs.hard)) } catch (e: Throwable) { "" }
                        if (d.isNotEmpty())
                            motor1 = if (Opus.ready) "ağ (OPUS boş döndü)" else "ağ"
                    }
                }
                if (aiCalisacak) {
                    // Yapay zekâya yol ver; yetişmezse bu çeviri basılır.
                    val yedek = d
                    val yedekMotor = motor1
                    workHandler?.postDelayed({
                        // Yerel çeviri basıldıysa EKRAN KİLİTLENİR: geç gelen
                        // yapay zekâ artık ekrana yazmaz, yalnız kayda geçer.
                        // Yoksa yazı 1,2 sn sonra bir daha değişiyordu.
                        if (goster(token, yedek, text, 1, yedekMotor + " (yapay zekâ yetişmedi)"))
                            ekranKilitli = true
                    }, AI_BEKLEME)
                } else {
                    goster(token, d, text, 1, motor1)
                }
            }

            // 3) Yapay zekâ: en doğru, sokak ağzına en sadık olan.
            if (aiCalisacak) {
                calistir(refiner) {
                    try {
                        aiDeneme++
                        val fine = Translator.ai(text, onceki, prefs)
                        if (goster(token, fine, text, 3, "yapay zekâ")) lastError = ""
                    } catch (e: Exception) {
                        val m = e.message ?: ""
                        aiHata++
                        sonAiHata = m.take(120)
                        lastError = m.take(160)
                        val quota = m.contains("429") || m.contains("quota", true) ||
                                m.contains("RESOURCE_EXHAUSTED", true)
                        val yogun = m.contains("high demand", true) || m.contains("overloaded", true) ||
                                m.contains("503") || m.contains("UNAVAILABLE", true)
                        // Kota dolduysa bir süre hiç istek atılmaz; üst üste
                        // denemek pencerenin toparlanmasını engelliyor.
                        if (quota) aiBeklemeSonu = System.currentTimeMillis() + 90000L
                        else if (yogun) aiBeklemeSonu = System.currentTimeMillis() + 20000L
                        // Yapay zekânın neden sustuğu çalışma kaydına yazılır;
                        // kaydı gönderince sebep doğrudan görünür.
                        val sebep = if (quota) "kota doldu" else m.take(70).ifEmpty { "yanıt yok" }
                        synchronized(kilit) {
                            if (token == showToken && kayitSira >= 0) {
                                zincir = zincir + " (yapay zekâ: " + sebep + ")"
                                lastEngine = zincir
                                Kayit.duzelt(kayitSira, lastTr, zincir)
                            }
                        }
                    }
                }
            }
        } finally {
            busy = false
            serbest(crop)
        }
    }

    /**
     * Çeviriyi ekrana basar ve kayda yazar. Aynı replik için daha iyi kalite
     * gelirse eskisinin yerine geçer, daha kötüsü gelirse hiç gözükmez.
     * Replik değiştiyse (token eskidi) geç gelen çeviri atılır.
     */
    private fun goster(token: Long, tr: String, en: String, kalite: Int, motor: String): Boolean {
        if (tr.isBlank()) return false
        synchronized(kilit) {
            if (token != showToken || gosterilenKalite >= kalite) return false
            val simdi = System.currentTimeMillis()
            // TEK SONUÇ KURALI.
            // Altyazı bir kez basıldıktan sonra ekrandaki yazı DEĞİŞMEZ.
            // Üç motoru yarıştırıp yazıyı okurken gözünün önünde iki kez
            // değiştirmek "altyazılar birbirine giriyor" demekti. Daha iyi
            // çeviri kısa bir pencere içinde gelirse yerine geçer; geç
            // gelirse yalnız çalışma kaydına yazılır.
            // Ekran kilitliyse (yerel çeviri basılmış, yapay zekâ geç kalmış)
            // yeni çeviri yalnız kayda yazılır, ekrandaki yazı değişmez.
            val gecKaldi = ekranKilitli
            gosterilenKalite = kalite
            if (!gecKaldi) {
                if (gosterimAni == 0L) gosterimAni = simdi
                translations++
                lastTr = tr
                lastEngine = motor
                Ocr.markDisplayed(tr)
                post(tr, en)
            }
            // Kayıtta motor ZİNCİRİ görünsün; eskiden yalnız sonuncusu
            // yazılıyordu ve ilk motorun çalışıp çalışmadığı anlaşılmıyordu.
            // Gecikme kayda yazılır: hangi motor kaç ms'de yetişti.
            val gecikme = if (okumaAni > 0L) (simdi - okumaAni) else 0L
            val etiket = (if (gecKaldi) "$motor (geç, basılmadı)" else motor) + " " + gecikme + "ms"
            if (kayitSira >= 0) {
                zincir = if (zincir.isEmpty()) etiket else "$zincir → $etiket"
                Kayit.duzelt(kayitSira, tr, zincir)
            } else {
                zincir = etiket
                kayitSira = Kayit.ekle(en, tr, zincir)
            }
            return !gecKaldi
        }
    }

    /** Uyarıyı en çok 12 saniyede bir gösterir; ekran uyarıya boğulmasın. */
    private fun noteError(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastToastAt < 12000) return
        lastToastAt = now
        main.post { toast(msg) }
    }

    private fun post(tr: String, en: String) {
        main.post { overlay?.set(tr, en) }
    }

    /** Altyazı yerine küçük bir tanı satırı yazar. */
    private fun note(text: String) {
        main.post { overlay?.setNote(if (text.isEmpty()) "" else "RealSub: " + text) }
    }

    // ------------------------------------------------------------ görüntü işleme
    private var bandBmp: Bitmap? = null

    /** Paylaşılan şerit bitmap'i geri verilmez; yalnız geçici kesitler atılır. */
    private fun serbest(bmp: Bitmap?) {
        if (bmp != null && bmp !== bandBmp && !bmp.isRecycled) bmp.recycle()
    }

    /**
     * Yalnızca gereken satırlar kopyalanır.
     *
     * Eskiden her karede tam ekran boyutunda (1080x2400 ≈ 10 MB) bir bitmap
     * ayrılıp dolduruluyordu: kare başına 20-40 ms ve sürekli çöp toplama.
     * Artık arabellek doğrudan taranacak satırın başına konumlanıyor ve aynı
     * bitmap tekrar tekrar kullanılıyor; kare başına maliyet 3-6 ms'ye düşüyor.
     */
    private fun cropRegion(img: Image): Bitmap? {
        val plane = img.planes[0]
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        if (pixelStride <= 0 || rowStride <= 0) return null
        val stridePx = rowStride / pixelStride      // dolgu dahil satır genişliği

        // Ekran dönerken eski ölçüde bir kare gelebilir; ölçüler karenin
        // kendisine göre sınırlanır, yoksa arabellek dışına taşınır.
        val iw = img.width
        val ih = img.height
        if (iw < 4 || ih < 4) return null
        val land = iw > ih
        val auto = prefs.autoRegion
        val l = if (auto) 0 else (iw * prefs.regionL(land)).toInt().coerceIn(0, iw - 2)
        val t = if (auto) (ih * prefs.scanFrom).toInt().coerceIn(0, ih - 2)
                else (ih * prefs.regionT(land)).toInt().coerceIn(0, ih - 2)
        val r = if (auto) iw else (iw * prefs.regionR(land)).toInt().coerceIn(l + 2, iw)
        val b = if (auto) ih else (ih * prefs.regionB(land)).toInt().coerceIn(t + 2, ih)
        cropTop = t
        val h = b - t
        if (h < 2) return null

        return try {
            val buf = plane.buffer
            buf.rewind()
            buf.position(t * rowStride)

            val onceki = bandBmp
            val serit: Bitmap
            if (onceki == null || onceki.width != stridePx || onceki.height != h || onceki.isRecycled) {
                try { onceki?.recycle() } catch (e: Throwable) { }
                serit = Bitmap.createBitmap(stridePx, h, Bitmap.Config.ARGB_8888)
                bandBmp = serit
            } else {
                serit = onceki
            }
            serit.copyPixelsFromBuffer(buf)

            // Sol/sağ kırpma gerekmiyorsa kopya HİÇ çıkarılmaz. Satır sonundaki
            // hizalama dolgusu (çoğu cihazda 8 piksel) okumayı etkilemiyor,
            // onun için kesit almaya değmez.
            if (l == 0 && r >= iw) serit
            else Bitmap.createBitmap(serit, l, 0, (r - l).coerceAtMost(stridePx - l), h)
        } catch (e: Throwable) {
            null
        }
    }

    /** Küçültülmüş parlaklık haritası; son hücre parlak piksel sayısını tutar. */
    private fun signature(bmp: Bitmap): IntArray {
        val w = 96
        val h = 26
        // filter=false: filtreli ölçekleme kare başına 5-10 ms yiyordu,
        // değişim sezmek için gereksiz hassasiyet.
        val small = Bitmap.createScaledBitmap(bmp, w, h, false)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        small.recycle()
        val out = IntArray(w * h + 1)
        var bright = 0
        for (i in px.indices) {
            val c = px[i]
            val g = ((c shr 16 and 0xFF) * 3 + (c shr 8 and 0xFF) * 6 + (c and 0xFF)) / 10
            out[i] = g
            // Aynı sebeple parlaklık eşiği düşürüldü; karanlık sahnede altyazı
            // varken "ekranda yazı yok" sanılıp okuma hiç yapılmıyordu. Ölçüm:
            // karanlık sahnede altyazı hücresi ~97; 110 ve 150 sıfır veriyor.
            if (g > 80) bright++
        }
        out[out.size - 1] = bright
        return out
    }

    private fun diff(a: IntArray, b: IntArray): Int {
        var d = 0
        for (i in 0 until a.size - 1) {
            // Eşikler KARANLIK SAHNE İÇİN fazla yüksekti (parlaklık>130, fark>45).
            // Hücreler 11x35 pikselin ortalaması olduğu için karanlık sahnedeki
            // beyaz altyazı 130'un altında kalıyor ve altyazının geldiği hiç
            // fark edilmiyordu: 706 karede yalnız 32 değişim.
            if ((a[i] > 70 || b[i] > 70) && Math.abs(a[i] - b[i]) > 28) d++
        }
        return d
    }

    // ------------------------------------------------------------ bildirim / kapanış
    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "RealSub", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val stop = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val flag = if (Build.VERSION.SDK_INT >= 23)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT
        val pi = PendingIntent.getService(this, 1, stop, flag)

        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("RealSub çalışıyor")
            .setContentText("Altyazı okunuyor — durdurmak için dokun")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun toast(s: String) {
        Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()
    }

    private fun stopEverything() {
        running = false
        try { dinleyiciBirak() } catch (e: Exception) { }
        try { workHandler?.removeCallbacksAndMessages(null) } catch (e: Exception) { }
        try { worker?.quitSafely() } catch (e: Exception) { }
        worker = null
        workHandler = null
        main.post { overlay?.hide() }
        try { display?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        display = null
        reader = null
        projection = null
        displayCreated = false
        try { bandBmp?.recycle() } catch (e: Throwable) { }
        bandBmp = null
        // Çeviri iş parçacıkları bırakılır; süreçte asılı kalmasın.
        // shutdownNow ÇALIŞANI KESİYORDU ("thread interrupted"). shutdown
        // devam eden isteğin bitmesine izin verir; yenisi Başlat'ta kurulur.
        try { anlik.shutdown() } catch (e: Throwable) { }
        try { hizli.shutdown() } catch (e: Throwable) { }
        try { refiner.shutdown() } catch (e: Throwable) { }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
