package com.realsub.app

import android.content.Context
import kotlinx.coroutines.runBlocking

/**
 * OPUS-MT köprüsü.
 *
 * GameLingo'nun anlık çevirisini sağlayan motor budur: Helsinki EN->TR
 * sinir ağı telefonda çalışır, internete hiç çıkmaz, kota ve anahtar
 * istemez. Model paketi kullanıcı tarafından bir kez yüklenir.
 *
 * Buradaki iş parçacıkları zaten arka planda olduğu için runBlocking
 * kullanmak güvenli; ana iş parçacığından ÇAĞRILMAZ.
 */
object Opus {

    @Volatile private var motor: OpusMtEngine? = null
    @Volatile var durum = "model yüklü değil"
        private set

    val ready: Boolean get() = motor?.ready == true

    fun kurulu(ctx: Context): Boolean = OpusModelPack.isInstalled(ctx)

    /** Arka planda hazırlar. Model yoksa sessizce döner. */
    fun hazirla(ctx: Context) {
        if (ready) return
        if (!OpusModelPack.isInstalled(ctx)) {
            durum = "model yüklü değil"
            return
        }
        durum = "model açılıyor"
        try {
            val m = motor ?: OpusMtEngine(ctx.applicationContext).also { motor = it }
            val ok = runBlocking { m.prepare() }
            durum = if (ok) "hazır" else ("açılamadı: " + (m.lastError ?: "bilinmeyen"))
        } catch (t: Throwable) {
            durum = "açılamadı: " + (t.message ?: t.javaClass.simpleName).take(60)
        }
    }

    /** Çevirir; hazır değilse ya da takılırsa boş döner, çağıran yedek motora düşer. */
    @Volatile var sonHata = ""
        private set

    fun translate(text: String): String {
        val m = motor
        if (m == null) { sonHata = "motor kurulmadı"; return "" }
        if (!m.ready) { sonHata = "motor hazır değil"; return "" }
        return try {
            val c = runBlocking { m.translate(text) }
            if (c.isNullOrBlank()) {
                // Sessizce boş dönmesin; sebebi kayıtta görünsün.
                sonHata = m.lastError ?: "boş çeviri döndü"
                ""
            } else { sonHata = ""; c }
        } catch (t: Throwable) {
            sonHata = (t.message ?: t.javaClass.simpleName).take(70)
            ""
        }
    }

    fun kapat() {
        try { motor?.close() } catch (t: Throwable) { }
        motor = null
        durum = "kapalı"
    }
}
