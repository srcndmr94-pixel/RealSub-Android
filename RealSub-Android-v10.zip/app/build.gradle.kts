plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.realsub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.realsub.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 10
        versionName = "10"
    }

    // Sabit imza: her derlemede aynı anahtarla imzalanır, böylece yeni APK
    // eskisinin ÜSTÜNE kurulur; silip yeniden kurmak gerekmez.
    signingConfigs {
        getByName("debug") {
            val ks = System.getenv("REALSUB_KEYSTORE")
            if (!ks.isNullOrBlank() && file(ks).exists()) {
                storeFile = file(ks)
                storePassword = "realsub"
                keyAlias = "realsub"
                keyPassword = "realsub"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Cihaz üstü çeviri modeli (Gemma). Model dosyası uygulamayla gelmez,
    // kullanıcı telefona koyup ayarlardan gösterir.
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
