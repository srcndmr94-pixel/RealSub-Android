package com.realsub.app

import android.content.Context
import android.content.Intent
import java.io.File

/**
 * Çalışma kaydı: ekranda çıkan her replik zamanıyla birlikte dosyaya yazılır.
 * Uygulama kapansa da kalır; istenirse .srt ya da düz metin olarak paylaşılır.
 */
object Kayit {

    private const val AD = "realsub-kayit.tsv"

    class Satir(val ms: Long, val en: String, val tr: String, val motor: String)

    private val liste = ArrayList<Satir>()
    private var dosya: File? = null
    private var t0 = 0L

    val sayi: Int get() = synchronized(liste) { liste.size }

    @Synchronized
    fun basla(ctx: Context) {
        if (dosya == null) dosya = File(ctx.filesDir, AD)
        if (liste.isEmpty()) oku()
        t0 = System.currentTimeMillis()
    }

    @Synchronized
    private fun oku() {
        val f = dosya ?: return
        if (!f.exists()) return
        try {
            f.forEachLine { satir ->
                val p = satir.split('\t')
                if (p.size >= 4) liste.add(Satir(p[0].toLongOrNull() ?: 0L, p[1], p[2], p[3]))
            }
        } catch (e: Exception) { }
    }

    @Synchronized
    fun ekle(en: String, tr: String, motor: String): Int {
        val ms = if (t0 == 0L) 0L else System.currentTimeMillis() - t0
        liste.add(Satir(ms, en, tr, motor))
        yaz(ms, en, tr, motor)
        return liste.size - 1
    }

    /** Yapay zekâ düzeltmesi geldiğinde son satırın çevirisi güncellenir. */
    @Synchronized
    fun duzelt(sira: Int, tr: String, motor: String) {
        if (sira < 0 || sira >= liste.size) return
        val e = liste[sira]
        liste[sira] = Satir(e.ms, e.en, tr, motor)
        tamYaz()
    }

    private fun yaz(ms: Long, en: String, tr: String, motor: String) {
        val f = dosya ?: return
        try {
            f.appendText(ms.toString() + "\t" + tek(en) + "\t" + tek(tr) + "\t" + tek(motor) + "\n")
        } catch (e: Exception) { }
    }

    @Synchronized
    private fun tamYaz() {
        val f = dosya ?: return
        try {
            val sb = StringBuilder()
            for (s in liste) sb.append(s.ms).append('\t').append(tek(s.en)).append('\t')
                .append(tek(s.tr)).append('\t').append(tek(s.motor)).append('\n')
            f.writeText(sb.toString())
        } catch (e: Exception) { }
    }

    private fun tek(s: String) = s.replace('\t', ' ').replace('\n', ' ')

    @Synchronized
    fun temizle() {
        liste.clear()
        try { dosya?.delete() } catch (e: Exception) { }
    }

    @Synchronized
    fun sonlar(adet: Int): List<Satir> =
        if (liste.size <= adet) ArrayList(liste) else ArrayList(liste.subList(liste.size - adet, liste.size))

    private fun zaman(ms: Long): String {
        val x = if (ms < 0) 0 else ms
        val h = x / 3600000
        val d = (x / 60000) % 60
        val s = (x / 1000) % 60
        val k = x % 1000
        return String.format("%02d:%02d:%02d,%03d", h, d, s, k)
    }

    /** Altyazı dosyası olarak dışa aktarır. */
    @Synchronized
    fun srt(ctx: Context): File? {
        if (liste.isEmpty()) return null
        val sb = StringBuilder()
        for (i in liste.indices) {
            val s = liste[i]
            val bitis = if (i + 1 < liste.size) maxOf(s.ms + 800, liste[i + 1].ms - 80) else s.ms + 2500
            sb.append(i + 1).append('\n')
                .append(zaman(s.ms)).append(" --> ").append(zaman(bitis)).append('\n')
                .append(s.tr).append('\n')
            if (s.en.isNotEmpty()) sb.append(s.en).append('\n')
            sb.append('\n')
        }
        return try {
            val f = File(ctx.cacheDir, "realsub-kayit.srt")
            f.writeText(sb.toString())
            f
        } catch (e: Exception) { null }
    }

    /** Paylaşma penceresi için hazır niyet. */
    fun paylas(ctx: Context): Intent? {
        val f = srt(ctx) ?: return null
        return try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                ctx, ctx.packageName + ".dosya", f
            )
            Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, "RealSub çalışma kaydı")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { null }
    }
}
