package com.realsub.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast

/**
 * Ekranı kaydeder, seçili alandaki altyazıyı okur, çevirir ve katmanda gösterir.
 * İstek yalnızca altyazı değiştiğinde gönderilir.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_TEST = "test"
        private const val CHANNEL = "realsub"
        private const val NOTIF_ID = 41
        @Volatile var running = false

        /** Durum ekranı için sayaçlar — aynı süreçte olduğumuz için doğrudan okunur. */
        @Volatile var frames = 0
        @Volatile var changes = 0
        @Volatile var reads = 0
        @Volatile var translations = 0
        @Volatile var lastOcr = ""
        @Volatile var lastTr = ""
        @Volatile var lastError = ""
        @Volatile var lastBright = 0
        @Volatile var forceOnce = false
        @Volatile var rotations = 0
        @Volatile var lastEngine = ""

        fun resetStats() {
            frames = 0; changes = 0; reads = 0; translations = 0; rotations = 0
            lastOcr = ""; lastTr = ""; lastError = ""; lastBright = 0; lastEngine = ""
        }
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    private lateinit var prefs: Prefs
    private var overlay: Overlay? = null

    private var worker: HandlerThread? = null
    private var workHandler: Handler? = null
    private val main = Handler(Looper.getMainLooper())

    private var sw = 0
    private var sh = 0
    private var lastSig: IntArray? = null
    private var changed = false
    private var quiet = 0
    private var lastText = ""
    private var prevText = ""
    private var busy = false
    private var failUntil = 0L
    private var lastToastAt = 0L
    private var cropTop = 0
    private var missCount = 0
    private var blackFrames = 0
    private var displayCreated = false
    /** Altyazının bulunduğu şerit (kırpılmış görüntüdeki dikey orta nokta). */
    private var band = -1f
    private var bandMiss = 0
    private var lastCropH = 0
    /** Yapay zekâ düzeltmesi geciktiğinde eski repliğin ekrana yazılmasını engeller. */
    @Volatile private var showToken = 0L
    private val refiner = java.util.concurrent.Executors.newSingleThreadExecutor()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        prefs = Prefs(this)

        if (intent?.action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_TEST) {
            forceOnce = true
            return START_STICKY
        }

        startForeground(NOTIF_ID, buildNotification())

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)

        if (code == 0 || data == null) {
            toast("Ekran izni alınamadı.")
            stopEverything()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (p == null) {
            toast("Ekran kaydı başlatılamadı.")
            stopEverything()
            return START_NOT_STICKY
        }
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopEverything() }
            }
        }, main)

        resetStats()
        band = -1f; bandMiss = 0; lastCropH = 0
        Ocr.forgetDisplayed()
        // Telefondaki model varsa arka planda yüklenir; ilk replikte hazır olur.
        val mp = prefs.modelPath
        if (mp.isNotEmpty()) Thread { LocalModel.ensure(applicationContext, mp) }.start()
        startCapture()
        running = true
        return START_STICKY
    }

    // ------------------------------------------------------------ ekran kaydı
    /** Ekranın o anki gerçek ölçüsü. Telefon döndüğünde en ve boy yer değiştirir. */
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun densityDpi(): Int {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return dm.densityDpi
    }

    private fun startCapture() {
        buildDisplay()
        overlay = Overlay(this, prefs).also { main.post { it.show() } }
        worker = HandlerThread("realsub-loop").also { it.start() }
        workHandler = Handler(worker!!.looper)
        workHandler?.post(loop)
    }

    /**
     * Sanal ekranı kurar ya da ölçüsünü günceller.
     *
     * ÖNEMLİ: Android aynı yakalama izniyle İKİNCİ bir sanal ekran kurdurtmuyor;
     * denenirse yakalama tamamen ölüyor ("kayıt kendi kendine kapanıyor").
     * Bu yüzden sanal ekran izin başına bir kez kurulur, ekran dönünce
     * bırakılıp yeniden kurulmaz, yalnızca boyutlandırılır.
     */
    @Synchronized
    private fun buildDisplay() {
        val (w, h) = screenSize()
        if (w <= 0 || h <= 0) return
        if (displayCreated && w == sw && h == sh) return

        val yeniReader = try {
            ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        } catch (e: Throwable) {
            lastError = "görüntü okuyucu kurulamadı"
            return
        }

        try {
            if (!displayCreated) {
                val vd = projection?.createVirtualDisplay(
                    "RealSub", w, h, densityDpi(),
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    yeniReader.surface, null, null
                )
                if (vd == null) {
                    yeniReader.close()
                    lastError = "sanal ekran kurulamadı"
                    return
                }
                display = vd
                displayCreated = true
            } else {
                val vd = display
                if (vd == null) { yeniReader.close(); return }
                // Sıra önemli: önce yüzeyi ayır, sonra boyutla, sonra yeni yüzeyi bağla.
                vd.setSurface(null)
                vd.resize(w, h, densityDpi())
                vd.setSurface(yeniReader.surface)
            }
        } catch (e: Throwable) {
            try { yeniReader.close() } catch (x: Throwable) { }
            lastError = "ekran kurulumu: " + (e.message ?: e.javaClass.simpleName).take(90)
            return
        }

        val eski = reader
        reader = yeniReader
        try { eski?.close() } catch (e: Throwable) { }

        sw = w
        sh = h
        lastSig = null
        band = -1f
        bandMiss = 0
        lastCropH = 0
    }

    private val loop = object : Runnable {
        override fun run() {
            try { tick() } catch (e: Exception) { }
            workHandler?.postDelayed(this, 450)
        }
    }

    private fun tick() {
        // Telefon döndüyse sanal ekran yeni ölçüyle yeniden kurulur.
        val (cw, ch) = screenSize()
        if (cw != sw || ch != sh) {
            rotations++
            buildDisplay()
            return
        }
        if (busy || System.currentTimeMillis() < failUntil) return
        val img = reader?.acquireLatestImage() ?: return
        val crop: Bitmap? = try { cropRegion(img) } finally { img.close() }
        if (crop == null) return

        frames++
        val sig = signature(crop)
        lastBright = sig[sig.size - 1]

        // Korumalı uygulama (Netflix vb.) kareyi tamamen siyah verir.
        var mn = 255
        var mx = 0
        for (i in 0 until sig.size - 1) { if (sig[i] < mn) mn = sig[i]; if (sig[i] > mx) mx = sig[i] }
        if (mx - mn < 6) {
            blackFrames++
            if (blackFrames == 8) note("ekran korumalı — bu uygulama paylaşımı engelliyor")
            if (blackFrames >= 8) { crop.recycle(); return }
        } else blackFrames = 0
        val blank = lastBright < (sig.size - 1) * 0.0015   // yazı yok
        val prev = lastSig
        if (prev != null) {
            val d = diff(sig, prev)
            // Otomatik kipte geniş alan taranır; oyundaki ışık/patlama boşuna tetiklemesin.
            val esik = if (prefs.autoRegion) 14 else 8
            if (d > esik) { changed = true; quiet = 0; changes++ } else if (changed) quiet++
        }
        lastSig = sig

        val force = forceOnce
        if (force) forceOnce = false

        if (blank && !force) {
            if (changed && quiet >= 1) {
                changed = false
                lastText = ""
                post("", "")
            }
            crop.recycle()
            return
        }
        if (!force && (!changed || quiet < 1)) { crop.recycle(); return }
        changed = false

        busy = true
        try {
            if (crop.height != lastCropH) { lastCropH = crop.height; band = -1f }
            val tol = crop.height * 0.13f
            var found = Ocr.detect(crop, prefs.autoRegion, band, tol)
            if (found == null && band >= 0f) {
                // Şeritte bir şey yok: birkaç denemeden sonra şerit serbest bırakılır.
                bandMiss++
                if (bandMiss >= 5) { band = -1f; bandMiss = 0; found = Ocr.detect(crop, prefs.autoRegion) }
            }
            reads++
            if (found == null) {
                val sebep = Ocr.lastReason
                lastOcr = if (Ocr.lastRaw.isNotEmpty()) "(elendi) " + Ocr.lastRaw else "(" + sebep + ")"
                missCount++
                if (missCount >= 4) {
                    lastText = ""
                    // Sessiz kalma: neden bir şey yazmadığını ekrana küçük harflerle söyle.
                    if (Ocr.lastRaw.isNotEmpty()) note(sebep + ": " + Ocr.lastRaw.take(60))
                    else note(sebep)
                }
                return
            }
            missCount = 0
            bandMiss = 0
            val text = found.text
            lastOcr = text
            // Altyazının şeridi öğrenilir; sonraki karelerde arayüz yazıları elenir.
            band = if (band < 0f) (found.top + found.bottom) / 2f
                   else band * 0.75f + ((found.top + found.bottom) / 2f) * 0.25f
            // Bulunan altyazının ekrandaki yeri: çeviri bunun üstüne yerleşir.
            overlay?.anchorTop = cropTop + found.top
            overlay?.anchorBottom = cropTop + found.bottom
            if (!force && Ocr.similar(text, lastText) > 0.85f) return
            lastText = text
            val token = ++showToken

            // 1) Taslak: önce telefondaki model (internetsiz), yoksa hızlı motor.
            var draft = ""
            if (LocalModel.ready) {
                draft = try { LocalModel.translate(text, prefs.hard) } catch (e: Throwable) { "" }
                if (draft.isNotEmpty()) lastEngine = "cihaz üstü model"
            }
            if (draft.isEmpty()) {
                draft = try { Translator.fast(text, prefs.hard) } catch (e: Exception) {
                    lastError = (e.message ?: "").take(160); ""
                }
                if (draft.isNotEmpty()) lastEngine = "hızlı motor"
            }
            if (draft.isNotEmpty()) {
                translations++
                lastTr = draft
                Ocr.markDisplayed(draft)
                post(draft, text)
            } else {
                // Çeviri gelmediyse hiç değilse okunan İngilizceyi göster:
                // ekran boş kalmasın, zincirin neresinin çalıştığı görünsün.
                post(text, "")
                lastEngine = "çeviri gelmedi — okunan gösteriliyor"
            }

            // 2) Düzeltme: yapay zekâ daha doğal karşılığı bulunca taslağın
            //    yerine geçer. Bu arada yeni bir replik geldiyse eskisi yazılmaz.
            val key = prefs.apiKey
            val onceki = prevText
            prevText = text
            if (key.isNotEmpty()) {
                refiner.execute {
                    try {
                        val fine = Translator.ai(text, onceki, prefs)
                        if (fine.isNotEmpty() && token == showToken) {
                            lastTr = fine
                            lastEngine = "yapay zekâ"
                            Ocr.markDisplayed(fine)
                            post(fine, text)
                            lastError = ""
                        }
                    } catch (e: Exception) {
                        val m = e.message ?: ""
                        lastError = m.take(160)
                        val quota = m.contains("429") || m.contains("quota", true) ||
                                m.contains("RESOURCE_EXHAUSTED", true)
                        noteError(if (quota) "Kota doldu — hızlı çeviri sürüyor" else "Yapay zekâ yetişemedi — hızlı çeviri gösteriliyor")
                    }
                }
            }
        } finally {
            busy = false
            crop.recycle()
        }
    }

    /** Uyarıyı en çok 12 saniyede bir gösterir; ekran uyarıya boğulmasın. */
    private fun noteError(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastToastAt < 12000) return
        lastToastAt = now
        main.post { toast(msg) }
    }

    private fun post(tr: String, en: String) {
        main.post { overlay?.set(tr, en) }
    }

    /** Altyazı yerine küçük bir tanı satırı yazar. */
    private fun note(text: String) {
        main.post { overlay?.setNote(if (text.isEmpty()) "" else "RealSub: " + text) }
    }

    // ------------------------------------------------------------ görüntü işleme
    private fun cropRegion(img: Image): Bitmap? {
        val plane = img.planes[0]
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val rowPad = rowStride - pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + rowPad / pixelStride, img.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)

        val land = sw > sh
        val auto = prefs.autoRegion
        val l = if (auto) 0 else (sw * prefs.regionL(land)).toInt().coerceIn(0, sw - 2)
        val t = if (auto) (sh * prefs.scanFrom).toInt().coerceIn(0, sh - 2)
                else (sh * prefs.regionT(land)).toInt().coerceIn(0, sh - 2)
        val r = if (auto) sw else (sw * prefs.regionR(land)).toInt().coerceIn(l + 2, sw)
        val b = if (auto) sh else (sh * prefs.regionB(land)).toInt().coerceIn(t + 2, sh)
        cropTop = t
        return try {
            val out = Bitmap.createBitmap(full, l, t, r - l, b - t)
            if (out != full) full.recycle()
            out
        } catch (e: Exception) {
            full.recycle()
            null
        }
    }

    /** Küçültülmüş parlaklık haritası; son hücre parlak piksel sayısını tutar. */
    private fun signature(bmp: Bitmap): IntArray {
        val w = 96
        val h = 26
        val small = Bitmap.createScaledBitmap(bmp, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        small.recycle()
        val out = IntArray(w * h + 1)
        var bright = 0
        for (i in px.indices) {
            val c = px[i]
            val g = ((c shr 16 and 0xFF) * 3 + (c shr 8 and 0xFF) * 6 + (c and 0xFF)) / 10
            out[i] = g
            if (g > 150) bright++
        }
        out[out.size - 1] = bright
        return out
    }

    private fun diff(a: IntArray, b: IntArray): Int {
        var d = 0
        for (i in 0 until a.size - 1) {
            if ((a[i] > 130 || b[i] > 130) && Math.abs(a[i] - b[i]) > 45) d++
        }
        return d
    }

    // ------------------------------------------------------------ bildirim / kapanış
    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "RealSub", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val stop = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val flag = if (Build.VERSION.SDK_INT >= 23)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT
        val pi = PendingIntent.getService(this, 1, stop, flag)

        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("RealSub çalışıyor")
            .setContentText("Altyazı okunuyor — durdurmak için dokun")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun toast(s: String) {
        Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()
    }

    private fun stopEverything() {
        running = false
        try { workHandler?.removeCallbacksAndMessages(null) } catch (e: Exception) { }
        try { worker?.quitSafely() } catch (e: Exception) { }
        worker = null
        workHandler = null
        main.post { overlay?.hide() }
        try { display?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        display = null
        reader = null
        projection = null
        displayCreated = false
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
