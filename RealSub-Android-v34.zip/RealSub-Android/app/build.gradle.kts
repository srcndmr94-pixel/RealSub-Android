plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.realsub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.realsub.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 34
        versionName = "34"
    }

    // Sabit imza: her derlemede aynı anahtarla imzalanır, böylece yeni APK
    // eskisinin ÜSTÜNE kurulur; silip yeniden kurmak gerekmez.
    signingConfigs {
        getByName("debug") {
            val ks = System.getenv("REALSUB_KEYSTORE")
            if (!ks.isNullOrBlank() && file(ks).exists()) {
                storeFile = file(ks)
                storePassword = "realsub"
                keyAlias = "realsub"
                keyPassword = "realsub"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Çevrimdışı İngilizce-Türkçe çeviri. Ağa çıkmadığı için 20-60 ms'de
    // yanıt verir; anlık altyazının omurgası budur. Model ~30 MB, bir kez iner.
    implementation("com.google.mlkit:translate:17.0.3")
    // Cihaz üstü OPUS-MT (Helsinki EN->TR) çalıştırıcısı. İnternet gerekmez;
    // model paketi kullanıcı tarafından bir kez yüklenir.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.22.0")
    // Cihaz üstü çeviri modeli (Gemma). Model dosyası uygulamayla gelmez,
    // kullanıcı telefona koyup ayarlardan gösterir.
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
