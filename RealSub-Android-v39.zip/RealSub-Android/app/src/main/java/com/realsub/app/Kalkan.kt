package com.realsub.app

import java.util.Locale

/**
 * KÜFÜR KALKANI.
 *
 * Makine çevirisi küfrü yumuşatır ya da cümleyi bozar. Türkçe tarafta kelime
 * değiştirmek de yetmez: "Don't fucking move" cümlesini Google "Siktir git
 * hareket etme" gibi bozuk çevirir.
 *
 * Doğru yol: pekiştirici küfür İNGİLİZCE cümleden çıkarılır (dilbilgisi
 * bozulmaz), sertliği Türkçe olarak cümlenin SONUNA eklenir:
 *   "Don't fucking move!" -> "Kıpırdama, amına koyayım!"
 *
 * İsim/ünlem olan küfürler yer tutucuyla korunur, çeviriden sonra Türkçe
 * karşılığı geri konur. Küfür hiçbir koşulda silinmez.
 */
object Kalkan {

    class Yuva(val jeton: String, val ingilizce: String, val turkce: String)
    class Korunmus(val metin: String, val yuvalar: List<Yuva>, val kuyruk: List<String> = emptyList())

    private const val SERT = "amına koyayım"
    private const val LANET = "lanet olsun"
    private const val HAFIF = "be"

    private val TR = Locale("tr", "TR")

    private class Kural(val re: Regex, val yerine: String, val kuyruk: String?)
    private fun k(p: String, r: String, kuyruk: String?) = Kural(Regex("(?i)$p"), r, kuyruk)

    private val kurallar: List<Kural> = listOf(
        k("\\b(don't|do not|doesn't|didn't)\\s+give\\s+a\\s+fuck\\b", "$1 care", SERT),
        k("\\b(don't|do not|doesn't|didn't)\\s+give\\s+a\\s+shit\\b", "$1 care", HAFIF),
        k("\\b(I'm|I am|we're|we are|you're|you are|he's|he is|she's|she is|they're|they are|it's|it is)\\s+(so\\s+|totally\\s+|completely\\s+|really\\s+)?fucked(?!\\s+up)\\b", "$1 $2ruined", SERT),
        k("\\bfucked[- ]up (?:shit|stuff|things?)\\b", "terrible things", SERT),
        k("\\b(is|was|that's|it's|this is|so|really|pretty)\\s+fucked[- ]up\\b", "$1 terrible", SERT),
        k("\\bfucked\\s+up\\b", "messed up", SERT),
        k("\\bfucking\\s+up\\b", "messing up", SERT),
        k("\\bfucks\\s+up\\b", "messes up", SERT),
        k("\\bfuck\\s+up\\b", "mess up", SERT),
        k("\\bfuck(?:ing|in'?)\\s+with\\b", "messing with", SERT),
        k("\\bfucks\\s+with\\b", "messes with", SERT),
        k("\\bfuck\\s+with\\b", "mess with", SERT),
        k("\\b(what|who|where|why|how|when)\\s+the\\s+(?:fuck|fucking hell)\\b", "$1 the hell", SERT),
        k("\\s+the\\s+fuck\\b", "", SERT),
        k("\\bfucking\\s+hell\\b", "damn it", SERT),
        k("\\bmotherfucking\\s+", "", SERT),
        k("\\bfuck(?:ing|in'?)\\s+", "", SERT),
        k("\\bgoddamn(?:ed)?\\s+", "", LANET),
        k("\\b(?:freaking|effing|frickin'?|friggin'?)\\s+", "", HAFIF),
        k("\\b(my|your|his|her|our|their) shit\\b", "$1 stuff", null),
        k("\\bthe (?:shit|crap|hell) out of (me|you|him|her|them|us|it)\\b", "$1 badly", SERT),
        k("\\bin deep shit\\b", "in big trouble", SERT),
        k("\\bget your shit together\\b", "pull yourself together", HAFIF),
        k("\\blife's a bitch\\b", "life is hard", LANET),
        k("\\bbitch(?:ing)?\\s+about\\b", "complaining about", null)
    )

    /** Bağlama göre karşılıklar; özel kalıplar ÖNCE gelir. */
    private val kelimeler: List<Pair<Regex, String>> = listOf(
        "holy shit" to "hassiktir",
        "oh,? shit" to "hassiktir",
        "no shit" to "yok artık",
        "pieces? of shit" to "pislik",
        "shit happens" to "olur böyle şeyler",
        "holy crap" to "vay anasını",
        "oh,? crap" to "hay aksi",
        "fuck no" to "hayatta olmaz",
        "fuck (?:that|this) shit" to "siktir et bunu",
        "(?<![\\p{L}'’] )shit(?=\\s*[,!?.…]|$)" to "siktir",
        "fuck yeah" to "işte bu be",
        "son of a bitch(?:es)?" to "orospu çocuğu",
        "motherfuckers?" to "orospu çocuğu",
        "go fuck yourself" to "siktir git",
        "fuck (?:off|you)" to "siktir git",
        "fuck (?:this|that|it)" to "siktir et",
        "bullshit" to "saçmalık",
        "horseshit" to "saçmalık",
        "shitty" to "berbat",
        "shits?" to "bok",
        "crap" to "zırva",
        "assholes?" to "pislik herif",
        "dickheads?" to "göt herif",
        "bitch(?:es)?" to "kaltak",
        "bastards?" to "piç",
        "pussy" to "korkak",
        "fuck(?:ed|s)?" to "siktir"
    ).map { Regex("(?i)\\b${it.first}\\b") to it.second }

    private val jetonlar = "abcdefghijklmnopqrstuvwxyz".map { "Zq$it" }

    /** "this fucking car" -> "bu lanet olası araba": isimden önceki küfür YERİNDE kalır. */
    private val yerinde = Regex(
        "(?i)\\b(this|that|the|my|your|his|her|our|their|a|an|these|those|some|every|no|whole|one)" +
            "\\s+(motherfucking|fucking|fuckin'?|goddamn(?:ed)?|damn|damned)\\s+(?=\\p{L})"
    )

    fun koru(metin: String): Korunmus {
        var t = metin
        val kuyruk = ArrayList<String>()
        val yuvalar = ArrayList<Yuva>()
        t = yerinde.replace(t) { m -> m.groupValues[1] + " damn " }
        for (r in kurallar) {
            if (r.re.containsMatchIn(t)) {
                t = r.re.replace(t, r.yerine)
                if (r.kuyruk != null && r.kuyruk !in kuyruk) kuyruk += r.kuyruk
            }
        }
        t = t.replace(Regex("\\s{2,}"), " ").trim()
        for ((re, tr) in kelimeler) {
            t = re.replace(t) { m ->
                if (yuvalar.size >= jetonlar.size) m.value
                else {
                    val jeton = jetonlar[yuvalar.size]
                    yuvalar += Yuva(jeton, m.value, tr)
                    jeton
                }
            }
        }
        // Cümlede zaten sert küfür kalıyorsa ayrıca "be" eklemeye gerek yok.
        val son = if (yuvalar.isNotEmpty()) kuyruk.filter { it != HAFIF } else kuyruk
        return Korunmus(t, yuvalar, son.take(1))
    }

    /** "Kıpırdama!" + "amına koyayım" -> "Kıpırdama, amına koyayım!" */
    fun kuyrukEkle(ceviri: String, kuyruk: List<String>): String {
        if (kuyruk.isEmpty() || ceviri.isBlank()) return ceviri
        val ek = kuyruk.first()
        if (ceviri.contains(ek, ignoreCase = true)) return ceviri
        val m = Regex("[.!?…]+$").find(ceviri.trimEnd())
        val govde = ceviri.trimEnd().removeSuffix(m?.value ?: "").trimEnd(',', ' ')
        val nokta = m?.value ?: ""
        return if (ek == HAFIF) "$govde $ek$nokta" else "$govde, $ek$nokta"
    }

    /** Jetonları Türkçe karşılığıyla değiştirir; biri kayıpsa null (yedek yol gerekir). */
    fun geriKoy(ceviri: String, yuvalar: List<Yuva>): String? {
        var t = ceviri
        for (y in yuvalar) {
            val re = Regex("(?i)\\b${y.jeton}(?:['’][\\p{L}]+)?")
            if (!re.containsMatchIn(t)) return null
            t = re.replace(t) { m ->
                val bastaMi = m.range.first == 0 ||
                    t.substring(0, m.range.first).trimEnd().let { it.isEmpty() || it.last() in ".!?…" }
                if (bastaMi) y.turkce.substring(0, 1).uppercase(TR) + y.turkce.substring(1) else y.turkce
            }
        }
        return t
    }

    /** Yedek yol: jetonları İngilizce kelimeye geri koyar. */
    fun jetonsuz(metin: String, yuvalar: List<Yuva>): String {
        var t = metin
        for (y in yuvalar) t = t.replace(y.jeton, y.ingilizce)
        return t
    }
}
