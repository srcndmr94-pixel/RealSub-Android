package com.realsub.app

/**
 * KALİTE KAPISI.
 *
 * Akıcı bir cümle, doğru bir çeviri demek değildir. Bu kapı çeviriyi
 * puanlamaz; yalnız MAKİNEYLE KANITLANABİLİR yapısal hataları yakalar:
 * çevrilmemiş İngilizce kalıntı, kaybolan olumsuzluk, uydurulmuş soru,
 * silinen küfür, tersine çevrilmiş emir.
 *
 * Hata bulunursa çağıran sıradaki motora geçer. İki hata sınıfı (anlamı
 * tersine çeviren emir) hiçbir koşulda ekrana basılmaz.
 *
 * NOT: Buraya tek bir filme/diziye özel satır YAZILMAZ. Kural genel
 * olacaksa kalır, örneğe bakarak yazılacaksa kalmaz.
 */
object Kapi {

    enum class Sorun {
        CEVRILMEMIS, UYDURMA_SORU, KAYIP_OLUMSUZ, KAYIP_KUFUR,
        KAYIP_SORU, INGILIZCE_KALINTI, TERS_EMIR, KAYIP_YASAK, EMIR_MASTAR
    }

    private val ingilizceKalinti = Regex(
        "\\b(?:the|you|your|we|they|this|that|with|from|would|should)\\b",
        RegexOption.IGNORE_CASE
    )
    private val olumsuzIng = Regex(
        "\\b(?:not|never|nothing|nobody|nowhere|cannot|can't|don't|doesn't|didn't|won't|" +
            "wouldn't|shouldn't|couldn't|isn't|aren't|wasn't|weren't)\\b",
        RegexOption.IGNORE_CASE
    )
    private val olumsuzTr = Regex(
        "(?<![\\p{L}])(?:değil(?:iz|im|sin|siniz|ler)?|yok|hayır|asla|hiç|kimse|hiçbir|olmaz|" +
            "olmadı|olmadık|olmayacak|istemiyorum|istemez|istemedim|yapmadı|yapmadık)(?![\\p{L}])" +
            "|(?:m[ae](?:d[ıiuü]|y[ae]c[ae]k|m[ıiuü]ş|m[ae]|z(?:di|miş)?))|(?:m[ıiuü]yor)" +
            // Emir kipinin olumsuzu sonda biter: "Kıpırdama!", "Gitme.", "Dokunma"
            // Bu olmadan doğru çeviri "olumsuzluk kayboldu" sanılıyordu.
            "|(?<=[\\p{L}])m[ae](?![\\p{L}])",
        RegexOption.IGNORE_CASE
    )
    private val deyimselOlumsuz = Regex("\\b(?:don['’]?t worry|never mind)\\b", RegexOption.IGNORE_CASE)

    private val kufurIng = Regex(
        "(?i)\\b(?:fuck(?:ing|ed|er)?|shit(?:ty)?|motherfucker|asshole|bitch|bastard|cunt)\\b"
    )
    private val kufurTr = Regex(
        "(?iu)(?:sik|siktir|sikti|sikik|amına|bok|piç|orospu|yavşak|kaltak|göt|ibne|lanet|hassiktir)"
    )

    /** Türkçe altyazıda kalmaması gereken İngilizce kısaltmalar. */
    private val kisaltmalar = Regex(
        "(?i)(?<![\\p{L}])(?:isn['’]t|aren['’]t|wasn['’]t|weren['’]t|doesn['’]t|didn['’]t|" +
            "couldn['’]t|wouldn['’]t|shouldn['’]t|what['’]s|who['’]s|you['’]re|they['’]re)(?![\\p{L}])"
    )

    // --- anlamı tersine çeviren haller -------------------------------------
    private val sifirSagKalan = Regex(
        "(?i)^(?:\\[[^]]+]\\s*)?(?:(?:leave|keep)\\s+(?:no\\s+one|nobody)\\s+(?:alive|breathing)" +
            "|spare\\s+(?:no\\s+one|nobody))[.!\\s]*$"
    )
    private val yanlisMerhamet = Regex(
        "(?iu)^(?:hiç\\s+)?(?:kimseyi|birini|onları|hepsini)\\s+(?:(?:sağ|canlı)\\s+)?" +
            "(?:bırak|bağışla|affet)(?:ın|ınız)?[.!\\s]*$"
    )
    private val yasakIng = Regex(
        "(?i)^(?:\\[[^]]+]\\s*)?(?:do\\s+not|don['’]t|never)\\s+(?!(?:worry|mind)\\b)[a-z]"
    )
    private val emirIng = Regex(
        "(?i)^(?:\\[[^]]+]\\s*)?(?:keep|go|come|move|stop|run|follow|leave|shut|hold|stay|take|" +
            "look|listen|shoot|wait)\\b"
    )
    private val mastarSonu = Regex("(?iu)\\b[\\p{L}]+m[ae]k\\s*[!.]*$")
    private val yasakTr = Regex(
        "(?iu)(?:\\b(?:sakın|asla|hiçbir|değil|yok|hayır)\\b|\\b[\\p{L}]+(?:ma|me)(?:\\b|[mydznslıiuüae][\\p{L}]*)" +
            "|\\b[\\p{L}]+m[ıiuü]yor[\\p{L}]*\\b)"
    )

    fun bak(kaynak: String, ceviri: String): Sorun? {
        val s = kaynak.trim()
        val t = ceviri.trim()
        if (s.isEmpty() || t.isEmpty() || s.equals(t, ignoreCase = true)) return Sorun.CEVRILMEMIS

        val tSade = t.replace(Regex("^\\[[^]]+]\\s*"), "")
        if (sifirSagKalan.matches(s) && yanlisMerhamet.matches(tSade)) return Sorun.TERS_EMIR
        if (yasakIng.containsMatchIn(s) && !yasakTr.containsMatchIn(tSade)) return Sorun.KAYIP_YASAK
        if (s.trimEnd().endsWith('!') && emirIng.containsMatchIn(s) && mastarSonu.containsMatchIn(tSade))
            return Sorun.EMIR_MASTAR

        if (!s.contains('?') && t.endsWith('?') && !s.endsWith("...") &&
            !s.contains('"') && !s.contains('“') && !s.contains(':')) return Sorun.UYDURMA_SORU

        // "Don't worry" -> "boş ver" doğru bir çeviridir; olumsuzluk kaybı sayılmaz.
        if (olumsuzIng.containsMatchIn(s) && s.length >= 18 &&
            !deyimselOlumsuz.containsMatchIn(s) &&
            !olumsuzTr.containsMatchIn(t) && !t.contains('?')) return Sorun.KAYIP_OLUMSUZ

        if (s.count { it == '?' } >= 2 && t.count { it == '?' } < s.count { it == '?' })
            return Sorun.KAYIP_SORU

        if (ingilizceKalinti.findAll(t).count() >= 2) return Sorun.CEVRILMEMIS
        if (kisaltmalar.containsMatchIn(t)) return Sorun.INGILIZCE_KALINTI

        if (kufurIng.containsMatchIn(s) && !kufurTr.containsMatchIn(t)) return Sorun.KAYIP_KUFUR
        return null
    }

    /** Yalnız bu iki hata çeviriyi ekrana basmayı tamamen engeller. */
    fun kesinRed(sorun: Sorun?): Boolean = when (sorun) {
        Sorun.TERS_EMIR, Sorun.EMIR_MASTAR -> true
        else -> false
    }

    /** Kapıyı geçen varsa onu seç; ikisi de geçmiyorsa birinciyi koru. */
    fun sec(kaynak: String, birinci: String, ikinci: String?): String {
        if (bak(kaynak, birinci) == null || ikinci.isNullOrBlank()) return birinci
        return if (bak(kaynak, ikinci) == null) ikinci else birinci
    }

    fun hafizayaUygun(kaynak: String, ceviri: String): Boolean = bak(kaynak, ceviri) == null
}
