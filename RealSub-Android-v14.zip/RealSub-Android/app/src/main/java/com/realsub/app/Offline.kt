package com.realsub.app

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.Translator as MlTranslator
import java.util.concurrent.TimeUnit

/**
 * Cihaz üstü (çevrimdışı) İngilizce-Türkçe çeviri.
 *
 * Ağa hiç çıkmadığı için yanıt 20-60 ms'de gelir; anlık altyazının omurgası
 * budur. Kalitesi yapay zekâ kadar iyi değildir ve küfrü kibarlaştırır, bu
 * yüzden çıktısı Translator.sertlestir ile geri sertleştirilir ve arkadan
 * gelen yapay zekâ çevirisi bunun yerine geçer.
 *
 * Model yaklaşık 30 MB'tır, bir kez inip telefonda kalır.
 */
object Offline {

    @Volatile var ready = false
        private set
    @Volatile var durum = "kapalı"
        private set

    private var client: MlTranslator? = null
    @Volatile private var indiriliyor = false

    /** Modeli hazırlar. Zaten hazırsa hiçbir şey yapmaz. */
    fun hazirla(ctx: Context) {
        if (ready || indiriliyor) return
        indiriliyor = true
        durum = "model hazırlanıyor"
        try {
            val c = client ?: Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.TURKISH)
                    .build()
            ).also { client = it }
            // requireWifi çağrılmıyor: mobil veriyle de insin, kullanıcı
            // başlat dediğinde beklemek istemiyor.
            val kosul = DownloadConditions.Builder().build()
            c.downloadModelIfNeeded(kosul)
                .addOnSuccessListener {
                    ready = true
                    indiriliyor = false
                    durum = "hazır"
                    // İlk çeviri ağır olur; şimdi ısıtılır ki ilk replik gecikmesin.
                    // Tasks.await ana iş parçacığında çağrılamaz, bu yüzden ayrı
                    // bir iş parçacığında yapılır (bu dinleyici ana iş parçacığında koşar).
                    Thread {
                        try { Tasks.await(c.translate("ready"), 8, TimeUnit.SECONDS) } catch (e: Throwable) { }
                    }.start()
                }
                .addOnFailureListener { e ->
                    indiriliyor = false
                    ready = false
                    durum = "model inmedi: " + (e.message ?: "bilinmeyen hata").take(60)
                }
        } catch (e: Throwable) {
            indiriliyor = false
            ready = false
            durum = "açılamadı: " + (e.message ?: "").take(60)
        }
    }

    /** Çevirir. Hazır değilse ya da takılırsa boş döner; çağıran ağa düşer. */
    fun translate(text: String): String {
        val c = client
        if (!ready || c == null) return ""
        return try {
            Tasks.await(c.translate(text), 1500, TimeUnit.MILLISECONDS) ?: ""
        } catch (e: Throwable) {
            ""
        }
    }

    fun kapat() {
        try { client?.close() } catch (e: Throwable) { }
        client = null
        ready = false
        durum = "kapalı"
    }
}
