package com.realsub.app

import android.content.Context
import kotlinx.coroutines.runBlocking

/**
 * OPUS-MT köprüsü.
 *
 * GameLingo'nun anlık çevirisini sağlayan motor budur: Helsinki EN->TR
 * sinir ağı telefonda çalışır, internete hiç çıkmaz, kota ve anahtar
 * istemez. Model paketi kullanıcı tarafından bir kez yüklenir.
 *
 * Buradaki iş parçacıkları zaten arka planda olduğu için runBlocking
 * kullanmak güvenli; ana iş parçacığından ÇAĞRILMAZ.
 */
object Opus {

    @Volatile private var motor: OpusMtEngine? = null
    @Volatile var durum = "model yüklü değil"
        private set

    val ready: Boolean get() = motor?.ready == true

    fun kurulu(ctx: Context): Boolean = OpusModelPack.isInstalled(ctx)

    /** Arka planda hazırlar. Model yoksa sessizce döner. */
    fun hazirla(ctx: Context) {
        if (ready) return
        if (!OpusModelPack.isInstalled(ctx)) {
            durum = "model yüklü değil"
            return
        }
        durum = "model açılıyor"
        try {
            val m = motor ?: OpusMtEngine(ctx.applicationContext).also { motor = it }
            val ok = runBlocking { m.prepare() }
            durum = if (ok) "hazır" else ("açılamadı: " + (m.lastError ?: "bilinmeyen"))
        } catch (t: Throwable) {
            durum = "açılamadı: " + (t.message ?: t.javaClass.simpleName).take(60)
        }
    }

    /** Çevirir; hazır değilse ya da takılırsa boş döner, çağıran yedek motora düşer. */
    @Volatile var sonHata = ""
        private set

    /**
     * Metni CÜMLELERE böler.
     *
     * Marian/OPUS modelleri çok cümleli girdide sondan kırpıyor:
     * "Boobie, huh? Yeah, he ain't here, though." girdisine yalnız
     * "Evet, burada değil." dönüyordu. Her cümle ayrı çevrilip birleştirilir.
     */
    private fun cumleler(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val c = text[i]
            sb.append(c)
            if (c == '.' || c == '!' || c == '?') {
                while (i + 1 < text.length && (text[i + 1] == '.' || text[i + 1] == '!' || text[i + 1] == '?')) {
                    i++; sb.append(text[i])
                }
                val p = sb.toString().trim()
                if (p.isNotEmpty()) out.add(p)
                sb.setLength(0)
            }
            i++
        }
        val kalan = sb.toString().trim()
        if (kalan.isNotEmpty()) out.add(kalan)
        return if (out.isEmpty()) listOf(text) else out
    }

    fun translate(text: String): String {
        val m = motor
        if (m == null) { sonHata = "motor kurulmadı"; return "" }
        if (!m.ready) { sonHata = "motor hazır değil"; return "" }
        return try {
            val parcalar = cumleler(text)
            val sb = StringBuilder()
            for (p in parcalar) {
                // Tek harflik ya da yalnız noktalamadan ibaret parçayı çevirme.
                if (p.length < 2) { sb.append(p); continue }
                val c = runBlocking { m.translate(p) }
                if (c.isNullOrBlank()) {
                    // Tek parça boş dönerse TAMAMINI atma; çalışan parçalar kalsın.
                    sonHata = m.lastError ?: "bir cümle boş döndü"
                    continue
                }
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(c.trim())
            }
            val sonuc = sb.toString().trim()
            if (sonuc.isEmpty()) { sonHata = "boş çeviri döndü"; "" } else { sonHata = ""; sonuc }
        } catch (t: Throwable) {
            sonHata = (t.message ?: t.javaClass.simpleName).take(70)
            ""
        }
    }

    fun kapat() {
        try { motor?.close() } catch (t: Throwable) { }
        motor = null
        durum = "kapalı"
    }
}
