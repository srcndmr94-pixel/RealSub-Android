package com.realsub.app

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Cihaz içi metin okuma ve "bu gerçekten altyazı mı" ayıklaması.
 * İnternet gerekmez, ücretsizdir.
 *
 * Eleme kuralları GameLingo'da sahada ayıklanmış kurallardan alınmıştır:
 * oynatıcı arayüzü, tuş uyarıları, konsol durum çubuğu, parçalanmış okuma
 * ve en önemlisi programın ekrana kendi yazdığı Türkçe metin elenir.
 */
object Ocr {

    private val client by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** Bulunan altyazı: metni ve tarama görüntüsündeki dikey yeri. */
    class Found(val text: String, val top: Int, val bottom: Int)

    /** Son denemede neden bir şey bulunamadığı; ekrana tanı satırı olarak yazılır. */
    /** Hangi filtrenin kaç replik elediği; kayıtta görünür. */
    private val elemeSayac = java.util.concurrent.ConcurrentHashMap<String, Int>()

    fun elemeSifirla() = elemeSayac.clear()

    /** "şeridin dışında 41 · arayüz 23 · çok küçük 12" gibi özet. */
    fun elemeOzeti(): String {
        if (elemeSayac.isEmpty()) return ""
        return elemeSayac.entries.sortedByDescending { it.value }
            .joinToString(" · ") { it.key + " " + it.value }
    }

    private fun ele(sebep: String): Nothing? {
        lastReason = sebep
        elemeSayac[sebep] = (elemeSayac[sebep] ?: 0) + 1
        return null
    }

    @Volatile var lastReason: String = ""
        private set

    /** Elendiği hâlde okunan ham metin; "okudu ama saymadı" durumunu görmek için. */
    @Volatile var lastRaw: String = ""
        private set

    // ------------------------------------------------------------------ sabitler

    private const val TURKISH_ONLY = "ığşİĞŞ"

    /** Yalnızca Türkçede sık geçen kelimeler: satır zaten Türkçeyse çevrilmez. */
    private val TURKCE_KELIMELER = setOf(
        "bir", "bu", "şu", "için", "ile", "çok", "daha", "var", "yok",
        "değil", "ama", "gibi", "kadar", "sonra", "önce", "şey", "evet",
        "hayır", "tamam", "devam", "edin", "halinde", "abone", "izlemeye",
        "ve", "veya", "ben", "sen", "biz", "siz", "onlar", "bizim", "senin",
        "benim", "nasıl", "neden", "nerede", "kim", "hangi", "oldu", "olur",
        "yapıyor", "geldi", "gitti", "dedi", "bilmiyorum", "görünüm", "diğer",
        "göster", "ürünleri", "videolar", "yorumlar", "paylaş", "kaydet"
    )

    /** Altyazı olmayan, ama altyazı bölgesine düşebilen yazılar. */
    private val BLOCK_PHRASES = listOf(
        // Android ekran kaydı uyarısı (Netflix, Prime vb.)
        "güvenlik nedeniyle", "uygulama içerikleri", "gizlendi",
        "secure content", "content is hidden",
        // Oynatıcı arayüzü
        "dialogue boost", "x-ray", "xray", "ekran görüntüsü",
        "alt yazı", "alt yazi", "altyazılar", "subtitles",
        "audio and subtitles", "audio & subtitles",
        "skip intro", "skip recap", "next episode", "watch credits",
        "episodes", "bölümler", "ses artırma", "ayarlar ve",
        // YouTube
        "ürünleri göster", "diğer videolar", "abone ol", "otomatik oynat",
        "daha sonra izle", "oynatma listesi", "izlenme", "show products",
        "watch later", "up next", "autoplay", "subscribe", "shorts",
        "sonraki video", "canlı yayın", "video kalitesi", "genişletilmiş",
        // Konsol / uzaktan oynatma
        "playstation", "play station", "xbox", "nintendo", "steam deck",
        "remote play", "uzaktan oynat", "dualsense", "ps remote"
    )

    private val UI_WORDS = setOf(
        "TOUCHPAD", "OPTIONS", "SKIP", "CONTINUE", "LOADING", "AUTOSAVE",
        "OBJECTIVE", "NEW OBJECTIVE", "MISSION", "CHECKPOINT"
    )

    /** Cümle kuran kelimeler: biri varsa satır repliktir, liste değildir. */
    private val SENTENCE_WORDS = setOf(
        "the", "a", "an", "is", "are", "was", "were", "be", "been",
        "i", "you", "he", "she", "we", "they", "it", "me", "him", "her",
        "my", "your", "his", "our", "their", "this", "that", "these",
        "to", "of", "in", "on", "at", "for", "with", "from", "by",
        "and", "or", "but", "if", "so", "not", "no", "yes",
        "do", "does", "did", "don't", "can", "can't", "will", "won't",
        "have", "has", "had", "get", "got", "go", "come", "know", "think",
        "what", "why", "how", "when", "where", "who"
    )

    /** Tek-iki harfli GERÇEK kelimeler; bunlar "kırıntı" sayılmaz. */
    private val KISA_KELIMELER = setOf(
        "a", "i", "am", "an", "as", "at", "be", "by", "do", "go", "he",
        "hi", "if", "in", "is", "it", "me", "my", "no", "of", "oh", "ok",
        "on", "or", "so", "to", "up", "us", "we", "ya", "yo", "ye", "ah",
        "ay", "eh", "uh", "um", "aw", "ow", "oi", "ha", "hm", "mm", "nah",
        "m", "s", "t", "d", "ll", "re", "ve", "em", "im", "id"
    )

    /** "Press O to throw", "Hold R2 to aim" türü tuş uyarıları. */
    private val TUS_UYARISI = Regex(
        "(?i)\\b(press|hold|tap|push)\\s+(?:and\\s+hold\\s+)?(?:the\\s+)?" +
                "([a-z]|[lr][123]|△|○|□|✕|circle|square|triangle|cross|touchpad|options)\\b"
    )

    /** Tek başına duran büyük harfler: HUD düğme simgeleri. I ve A sayılmaz. */
    private val TEK_HARF_SIMGE = Regex("(?<![\\p{L}'])[B-HJ-Z](?![\\p{L}'])")

    // ---------------------------------------------- kendi yazdığımız metnin takibi

    private val displayed = ArrayDeque<String>()

    /** Ekrana yazdığımız çeviri kaydedilir; sonraki karede tekrar okunursa elenir. */
    @Synchronized
    fun markDisplayed(tr: String) {
        val n = normalize(tr)
        if (n.length < 4) return
        displayed.addLast(n)
        while (displayed.size > 8) displayed.removeFirst()
    }

    @Synchronized
    fun forgetDisplayed() = displayed.clear()

    private fun normalize(s: String): String = s.lowercase()
        .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g')
        .replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')
        .replace('â', 'a').replace('î', 'i').replace('û', 'u')
        .filter { it.isLetterOrDigit() }

    /** Satır zaten Türkçe mi? Öyleyse çevirmenin anlamı yok. */
    /**
     * İngilizce altyazıda bulunması beklenen sık kelimeler.
     * Ekrandaki reklam/arayüz yazıları ("9Rand En geç Cum - Ücretsiz") bu
     * kelimelerin hiçbirini içermiyor ve İngilizce sanılıp çeviriye gidiyordu.
     */
    private val INGILIZCE_SIK = setOf(
        "the","a","an","i","you","he","she","it","we","they","me","him","her","them","my","your",
        "is","are","was","were","be","been","am","do","does","did","don","didn","doesn","can",
        "cant","will","wont","would","could","should","have","has","had","get","got","go","going",
        "to","of","in","on","at","for","with","from","that","this","these","those","and","but",
        "or","if","so","not","no","yes","yeah","yep","nah","ok","okay","hey","yo","huh","oh","ah",
        "what","where","when","why","how","who","all","just","like","know","think","want","need",
        "come","here","there","now","then","man","dude","bro","shit","fuck","damn","hell","aint",
        "gonna","wanna","gotta","let","look","see","say","said","tell","told","make","take","put"
    )

    /**
     * Animasyonlu başlık yazısı mı?
     *
     * Fragman jeneriklerinde yazı belirip kaybolurken OCR aynı kelimeyi
     * üst üste okuyor: "EXPERIENCE XPERIENCE EXPERIENCE THE ADVENTURE
     * TE ADVENTURE THE ADVENTURE". Normal bir replikte bu kadar tekrar olmaz.
     */
    private fun tekrarliOkuma(text: String): Boolean {
        val k = text.lowercase().split(Regex("[^a-zçğıöşü']+")).filter { it.length >= 3 }
        if (k.size < 4) return false
        val benzersiz = HashSet(k)
        // Kelimelerin yarısından fazlası tekrarsa animasyon artığıdır.
        return benzersiz.size * 2 <= k.size
    }

    /**
     * Ekran yazısı mı?
     *  a) Türkçeye özgü harf taşıyan iki ya da daha çok kelime varsa Türkçedir
     *     ("I Urünleri gösten (O" böyle geçiyordu: "i" İngilizce sayılıyordu).
     *  b) Üç kelimeden uzun bir satırda tek bir sık İngilizce kelime bile yoksa.
     */
    private fun ingilizceDegil(text: String): Boolean {
        val k = text.lowercase().split(Regex("[^a-zçğıöşü']+")).filter { it.isNotEmpty() }
        if (k.isEmpty()) return false
        var trKelime = 0
        for (w in k) if (w.any { it in "çğıöşü" }) trKelime++
        if (trKelime >= 2) return true
        if (k.size < 3) return false
        return k.none { INGILIZCE_SIK.contains(it.trim('\'')) }
    }

    private fun zatenTurkce(text: String): Boolean {
        if (text.any { it in TURKISH_ONLY }) return true
        for (k in text.lowercase().split(Regex("[^\\p{L}]+"))) {
            if (k.length >= 2 && k in TURKCE_KELIMELER) return true
        }
        return false
    }

    /**
     * Ekranda bizim yazdığımız Türkçe metin mi?
     * Kendi yazımız yeniden okunursa metin her turda büyüyerek geri gelir;
     * parça eşleşmesi bu döngüyü kırar.
     */
    @Synchronized
    private fun isOurOwnText(text: String): Boolean {
        if (zatenTurkce(text)) return true
        val simdi = normalize(text)
        if (simdi.isEmpty()) return false
        for (eski in displayed) {
            if (eski == simdi) return true
            // Parça eşleşmesi yalnızca iki taraf da uzunsa geçerli: kısa bir
            // replik ("Run!" -> "run") uzun bir Türkçe cümlenin içinde rastgele
            // geçebiliyor ve gerçek altyazı elenmiş oluyordu.
            if (simdi.length < 8 || eski.length < 8) continue
            val kisa = minOf(simdi.length, eski.length)
            val uzun = maxOf(simdi.length, eski.length)
            if (kisa * 10 >= uzun * 4 && (simdi.contains(eski) || eski.contains(simdi))) return true
        }
        return false
    }

    // ------------------------------------------------------------------ okuma

    fun detect(bmp: Bitmap, auto: Boolean, band: Float = -1f, bandTol: Float = 0f): Found? {
        val latch = CountDownLatch(1)
        var lines: List<Pair<String, Rect>> = emptyList()
        try {
            client.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { r ->
                    val acc = ArrayList<Pair<String, Rect>>()
                    for (block in r.textBlocks) for (ln in block.lines) {
                        val box = ln.boundingBox ?: continue
                        if (ln.text.isNotBlank()) acc.add(ln.text to box)
                    }
                    lines = acc
                    latch.countDown()
                }
                .addOnFailureListener { latch.countDown() }
        } catch (e: Exception) {
            return null
        }
        // 6 saniye çok uzun: takılan bir okuma tüm hattı kilitliyordu.
        latch.await(2500, TimeUnit.MILLISECONDS)
        if (lines.isEmpty()) { lastRaw = ""; return ele("yazı görülmedi") }

        val w = bmp.width
        val h = bmp.height

        // Çok küçük ya da çok dar parçalar atılır.
        var pool = lines.filter { (_, b) ->
            // Eşik %3 iken fragman/dizi altyazısı gibi küçük yazılar
            // "yazı çok küçük" diye eleniyordu. %2'ye indirildi.
            b.height() >= maxOf(7, (h * 0.02f).toInt()) && b.width() >= w * 0.03f
        }
        if (pool.isEmpty()) { return ele("çok küçük") }

        if (auto) {
            // Ortaya yakın duranlar altyazıdır; kenarda kalanlar arayüzdür.
            val cx = w / 2f
            val central = pool.filter { (_, b) -> Math.abs((b.left + b.right) / 2f - cx) < w * 0.42f }
            if (central.isNotEmpty()) pool = central

            // Şerit biliniyorsa dışına bakılmaz.
            if (band >= 0f) {
                val inBand = pool.filter { (_, b) -> Math.abs((b.top + b.bottom) / 2f - band) <= bandTol }
                if (inBand.isEmpty()) { return ele("şeridin dışında") }
                pool = inBand
            }
        }

        // EN ALTTAKİ KÜME YETMİYOR.
        //
        // Ekranın en altında bizim kendi Türkçe altyazımız ve oyunun yaş
        // sınırı yazısı (esrb.org) duruyor; ikisi de oyunun altyazısından
        // DAHA AŞAĞIDA. Eskiden en alttaki küme alınıp elenince hiç okuma
        // yapılmıyordu, yani gerçek altyazıya hiç bakılmıyordu. Artık küme
        // elenirse bir üsttekine geçilir.
        var kalan = pool.sortedBy { it.second.top }
        var deneme = 0
        var sonSebep = "satır kümesi boş"
        while (kalan.isNotEmpty() && deneme < 4) {
            deneme++
            val group = enAlttakiKume(kalan, h)
            if (group.isEmpty()) break

            val ham = group.joinToString(" ") { it.first }.replace('\n', ' ').trim()
            lastRaw = ham
            val text = temizle(ham)
            val sebep = when {
                text.isEmpty() -> "okunan yazı anlamsız"
                isOurOwnText(text) -> "kendi yazımız / zaten Türkçe"
                ingilizceDegil(text) -> "İngilizce değil (ekran yazısı)"
                tekrarliOkuma(text) -> "animasyonlu başlık (tekrarlı okuma)"
                altyaziDegil(text) -> "altyazı sayılmadı"
                arayuzYazisi(text) -> "arayüz yazısı sayıldı"
                else -> ""
            }
            if (sebep.isEmpty()) {
                lastReason = ""
                return Found(text, group.first().second.top, group.last().second.bottom)
            }
            sonSebep = sebep
            ele(sebep)
            // Bu küme elendi; onun ve altındaki her şeyin üstüne bak.
            var ust = Int.MAX_VALUE
            for (g in group) if (g.second.top < ust) ust = g.second.top
            val sinir = ust
            kalan = kalan.filter { it.second.bottom <= sinir }
        }
        lastReason = sonSebep
        return null
    }

    /** Alttan yukarı doğru, araları fazla açılmayan en çok üç satır. */
    private fun enAlttakiKume(
        satirlar: List<Pair<String, Rect>>,
        seritYuksekligi: Int
    ): List<Pair<String, Rect>> {
        if (satirlar.size <= 1) return satirlar
        val boslukEsigi = (seritYuksekligi * 0.14f).toInt().coerceAtLeast(12)
        val sonuc = ArrayList<Pair<String, Rect>>()
        var oncekiUst = satirlar.last().second.top
        for (i in satirlar.indices.reversed()) {
            val satir = satirlar[i]
            if (sonuc.isNotEmpty() && oncekiUst - satir.second.top > boslukEsigi) break
            sonuc.add(satir)
            oncekiUst = satir.second.top
            if (sonuc.size >= 3) break
        }
        return sonuc.reversed()
    }

    // ------------------------------------------------------------------ ayıklama

    private fun temizle(raw: String): String {
        var t = raw.replace('\n', ' ').replace('|', 'I')
        t = t.replace(Regex("[\\[\\]{}<>*_]"), " ")
        t = t.replace(Regex("\\s+"), " ").trim()
        if (t.length < 2) return ""
        val letters = t.count { it.isLetter() }
        if (letters < t.length / 3) return ""
        return t
    }

    /** Altyazı olmayan satırları eler. */
    private fun altyaziDegil(text: String): Boolean {
        val kucuk = text.lowercase()
        for (kalip in BLOCK_PHRASES) if (kucuk.contains(kalip)) return true

        val kelimeler = text.split(Regex("\\s+")).filter { it.isNotBlank() }

        val sikisik = kucuk.filter { !it.isWhitespace() }
        if (sikisik.contains("en•tr") || sikisik.contains("tr•en")) return true

        // Dosya adı, boyut, süre: telefonun kendi arayüzü.
        if (Regex("\\.(zip|apk|rar|pdf|mp4|png|jpg)\\b").containsMatchIn(kucuk)) return true
        if (Regex("\\d+[.,]?\\d*\\s?(mb|kb|gb)\\b").containsMatchIn(kucuk)) return true
        if (Regex("\\d+[.,]?\\d*\\s?(mn|sa|dk|sn|hr|min)\\b").findAll(kucuk).count() >= 2) return true
        if (Regex("\\d{1,2}:\\d{2}").containsMatchIn(text)) return true

        // Anahtar/adres parçası: uzun, harf ve rakam karışık.
        for (k in kelimeler) {
            if (k.length < 16) continue
            if (k.any { it.isDigit() } && k.any { it.isLetter() }) return true
        }

        // Parçalanmış okuma: kırıntı bol. Gerçek kısa kelimeler kırıntı sayılmaz.
        if (kelimeler.size >= 3) {
            val kirinti = kelimeler.count { k ->
                val sade = k.lowercase().trim('.', ',', '!', '?', ':', ';', '"', '\'', '’', '-', '…')
                sade.length <= 2 && sade !in KISA_KELIMELER
            }
            if (kirinti >= 3 && kirinti * 2 >= kelimeler.size) return true
        }

        if (kelimeler.size < 5) return false

        // Cümle kuran kelime varsa repliktir.
        for (k in kelimeler) {
            val sade = k.lowercase().trim('.', ',', '!', '?', ':', ';', '"', '\'')
            if (sade in SENTENCE_WORDS) return false
        }
        if (text.count { it == '.' || it == '!' || it == '?' } >= 2) return false

        // Jenerik listesi: baş harfi büyük özel adlar.
        val ozelAd = kelimeler.count { k ->
            k.length > 1 && k[0].isUpperCase() &&
                    k.drop(1).all { it.isLowerCase() || it == '.' || it == '-' }
        }
        return ozelAd >= 5
    }

    /** Tuş uyarısı, HUD çubuğu, sayaç gibi arayüz yazılarını eler. */
    private fun arayuzYazisi(metin: String): Boolean {
        val s = metin.trim()
        if (s.isEmpty()) return true
        // Noktalamayla biten satır repliktir.
        if (s.last() in ".!?…,:;\"'’") return false
        if (s.startsWith("[") || s.startsWith("(")) return false
        if (TUS_UYARISI.containsMatchIn(s)) return true
        if (TEK_HARF_SIMGE.findAll(s).count() >= 2) return true
        if (s.trim().uppercase() in UI_WORDS) return true

        // BURASI ALTYAZILARI YİYORDU.
        // Eski kurallar: "2 kelimeden kısa her satır arayüzdür" ve
        // "4 kelimeye kadar büyük harfli her satır arayüzdür". OCR cümle
        // sonundaki noktayı sık kaçırdığı için "Pick up", "Hold on",
        // "Right inside" gibi GERÇEK replikler eleniyordu; fragman
        // altyazıları da zaten büyük harfli. 238 elemenin 162'si buradandı.
        // Artık yalnız TEK KELİMELİK, tamamı büyük harfli kısa yazılar
        // (MENU, RELOAD, PAUSE) arayüz sayılır.
        val kelimeler = s.split(Regex("\\s+")).filter { it.isNotBlank() }
        val harfler = s.filter { it.isLetter() }
        val hepsiBuyuk = harfler.isNotEmpty() && harfler.all { it.isUpperCase() }
        if (kelimeler.size <= 1 && hepsiBuyuk && s.length <= 14) return true
        return false
    }

    /** İki okuma arasındaki benzerlik (0..1); aynı satırın tekrar çevrilmesini engeller. */
    /**
     * Okuma çıktısını temizler.
     *
     * OCR kelimeleri birbirine yapıştırıyor: "Itold Brian", "IImean",
     * "ofincoming". Çalışan uygulamalar bu temizliği çeviriden ÖNCE yapıyor;
     * bizde yoktu ve yapışık kelime olduğu gibi çeviriye gidiyordu.
     */
    private val I_FIILLERI = setOf(
        "told", "said", "mean", "know", "think", "guess", "saw", "got", "want",
        "need", "have", "had", "was", "am", "will", "can", "did", "do", "don",
        "didn", "wasn", "would", "could", "should", "like", "love", "hate",
        "heard", "feel", "felt", "thought", "swear", "promise", "remember"
    )

    fun temizleOkuma(ham: String): String {
        var t = ham
        // Tek başına küçük "l" → "I" (OCR büyük I'yı küçük l okuyor:
        // "l already told..."). Tek harflik "l" İngilizcede kelime değil.
        t = Regex("\\bl\\b").replace(t, "I")
        // "IImean" → "I mean" (OCR büyük I'yı ikizliyor)
        t = Regex("\\bII([a-z]{2,})\\b").replace(t) { m -> "I " + m.groupValues[1] }
        // "Itold" → "I told" (yalnız bilinen fiillerde, yanlış bölmemek için)
        t = Regex("\\bI([a-z]{2,})\\b").replace(t) { m ->
            if (I_FIILLERI.contains(m.groupValues[1].lowercase())) "I " + m.groupValues[1]
            else m.value
        }
        // "DMGto" → "DMG to": büyük harf dizisine yapışmış küçük harfli kelime
        t = Regex("\\b([A-Z]{2,})([a-z]{2,})\\b").replace(t) { m ->
            m.groupValues[1] + " " + m.groupValues[2]
        }
        // "sanaBak" → "sana Bak": küçük harften büyük harfe geçiş
        t = Regex("([a-zçğıöşü])([A-ZÇĞİÖŞÜ][a-zçğıöşü]{2,})").replace(t) { m ->
            m.groupValues[1] + " " + m.groupValues[2]
        }
        // Satır sonundaki arayüz artıkları: "RAYMOND? O", "big guy? STUDY (R1)",
        // "(O", "[X]" gibi düğme ipuçları ve tek harflik kalıntılar.
        // Düğme ipucu: "(R1)", "(X)" gibi parantezli kalıntı.
        t = t.replace(Regex("\\s*\\((?:R1|R2|L1|L2|X|Y|A|B|O)\\)\\s*$"), "")
        // Cümle BİTTİKTEN SONRA gelen BÜYÜK HARFLİ arayüz kelimesi:
        // "big guy? STUDY (R1)". Noktalama şartı var ki "GET OUT" gibi
        // bağıran gerçek replikler kesilmesin.
        t = t.replace(Regex("([.!?])\\s+[A-ZÇĞİÖŞÜ]{3,}(?:\\s*\\([A-Z0-9]{1,3}\\))?\\s*$"), "$1")
        // Cümleden sonra tek başına kalmış tek harf: "RAYMOND? O"
        t = t.replace(Regex("([.!?])\\s+[A-ZÇĞİÖŞÜ]\\s*$"), "$1")
        // Yarım kalmış açılış parantezi.
        t = t.replace(Regex("\\s*\\(\\s*$"), "")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    fun similar(a: String, b: String): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        if (a == b) return 1f
        val x = normalize(a)
        val y = normalize(b)
        if (x.isEmpty() || y.isEmpty()) return 0f
        if (x == y) return 1f
        val short = if (x.length < y.length) x else y
        val long = if (x.length < y.length) y else x
        if (long.contains(short) && short.length > long.length * 0.8) return 0.95f
        var same = 0
        val n = minOf(x.length, y.length)
        for (i in 0 until n) if (x[i] == y[i]) same++
        val harf = same.toFloat() / maxOf(x.length, y.length)

        // Harf harf karşılaştırma TEK harflik okuma hatasında çöküyor:
        // "Hell, it was..." ile "Hel, it was..." arasında bir harf eksilince
        // bütün dizi kayıyor ve benzerlik sıfıra iniyor. Aynı replik üç kez
        // okunup üç kez çevriliyordu. Kelime karşılaştırması buna dayanıklı.
        val ax = x.split(" ").filter { it.isNotEmpty() }
        val by = y.split(" ").filter { it.isNotEmpty() }
        if (ax.isEmpty() || by.isEmpty()) return harf
        val kalan = ArrayList(by)
        var ortak = 0
        for (w in ax) {
            val e = kalan.indexOfFirst { kelimeAyni(w, it) }
            if (e >= 0) { kalan.removeAt(e); ortak++ }
        }
        val kelime = ortak.toFloat() / maxOf(ax.size, by.size)

        // Kelime puanı yalnız ÇOK yüksekken söz sahibi olur. Okuma hatasında
        // kelimelerin hepsi (bozuk olanlar dahil) eşleşir ve puan 1'e yakındır.
        // Gerçekten farklı bir replikte ise en az bir kelime bambaşkadır:
        // "speed up" ile "speed down" 0,92 çıkıyordu ve ikinci replik
        // atlanıyordu. Eşik 0,95 bunu ayırıyor.
        return if (kelime >= 0.95f) kelime else harf
    }

    /** İki kelime aynı mı; tek harflik okuma hatasına göz yumar. */
    private fun kelimeAyni(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 3 || b.length < 3) return false
        val fark = a.length - b.length
        if (fark > 1 || fark < -1) return false
        val uzun = if (a.length >= b.length) a else b
        val kisa = if (a.length >= b.length) b else a
        var i = 0
        var j = 0
        var hata = 0
        while (i < uzun.length && j < kisa.length) {
            if (uzun[i] == kisa[j]) { i++; j++ }
            else {
                hata++
                if (hata > 1) return false
                if (uzun.length == kisa.length) { i++; j++ } else i++
            }
        }
        if (i < uzun.length) hata += uzun.length - i
        return hata <= 1
    }
}
