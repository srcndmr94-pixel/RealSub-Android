package com.realsub.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Çeviri. Ağ işi olduğu için yalnızca arka plan iş parçacığından çağrılır. */
object Translator {

    /**
     * Çeviri önbelleği. Dizilerde ve oyunlarda aynı replik sık sık tekrar
     * eder; tekrarda ağa hiç çıkılmaz, çeviri anında basılır.
     */
    /** Modelin thinkingConfig alanını kabul ettiği anlaşılana kadar denenir. */
    @Volatile private var dusunmeDestekli = true

    private val onbellek = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>): Boolean =
            size > 300
    }

    @Synchronized private fun bellektenAl(k: String): String? = onbellek[k]

    @Synchronized private fun bellegeKoy(k: String, v: String) {
        if (v.isNotEmpty()) onbellek[k] = v
    }

    fun bellegiTemizle() {
        synchronized(this) { onbellek.clear() }
    }

    /**
     * Sertlik, YALNIZCA kaynaktaki küfrün nasıl karşılanacağını belirler.
     * Hiçbir seviye "küfür ekle" demez: eski metin ("hiçbir şeyi yumuşatma,
     * en sert karşılığı kullan") modele temiz replikleri de küfürlü çevirtiyor
     * ve "Oh my god" → "Ananı avradını" gibi sonuçlar çıkıyordu.
     */
    private val HARD_RULES = arrayOf(
        "Kaynakta küfür varsa yumuşat, argoyu sadeleştir; aile ortamında izlenebilir bir dil kullan.",
        "Kaynakta küfür varsa ölçülü ama gerçek karşılığıyla ver, tamamen silme. Doğal konuşma Türkçesi kullan.",
        "Kaynakta küfür ya da argo varsa SOKAK AĞZIYLA, olduğu gibi karşıla: yumuşatma, kibarlaştırma, sansürleme. 'fuck' kelimesini 'kahretsin' diye geçiştirme, bağlama göre gerçek karşılığını yaz.",
        "Kaynakta küfür varsa TAM KARŞILIĞINI yaz: sansürleme, yıldızlama, hafifletme. En ağır küfür bile olduğu gibi çevrilir."
    )

    private fun systemPrompt(hard: Int): String = buildString {
        append("Sen deneyimli bir altyazı çevirmenisin. Ekrandan okunmuş İngilizce altyazıyı Türkçeye çeviriyorsun.\n\n")
        append("KURALLAR:\n")
        append("1. ").append(HARD_RULES[hard.coerceIn(0, 3)]).append("\n")
        // EN ÖNEMLİ KURAL: sertlik ayarı sansürü kaldırmak içindir, küfür
        // uydurmak için değil. Bu kural olmadan model temiz replikleri de
        // küfürlü çeviriyor.
        append("2. KAYNAKTA KÜFÜR YOKSA ÇEVİRİYE KÜFÜR EKLEME. Sertlik ayarı, var olan küfrü sansürlememek içindir; olmayan küfrü uydurmak için değil. ")
        append("\"oh my god\", \"come here\", \"look at you\" gibi temiz replikler TEMİZ çevrilir. ")
        append("Kaynakta karşılığı olmayan \"lan\", \"amına koyayım\", \"ananı avradını\" gibi ekler KOYMA.\n")
        append("3. Çevirinin tonu kaynağın tonuyla aynı olsun: kibar replik kibar, kaba replik kaba, şaşkınlık şaşkınlık.\n")
        append("4. Kelimesi kelimesine değil; o repliği Türkçe konuşan biri nasıl söylerdi, öyle çevir.\n")
        append("5. Metin ekrandan okunduğu için harf hatası olabilir; anlamı tamamla, hatayı düzelt.\n")
        append("6. Altyazı kısalığına uy: en çok iki satır.\n")
        append("7. Özel adlar, takma adlar ve oyun terimleri ASLA çevrilmez; harfi harfine olduğu gibi yazılır. ")
        append("Bir ad Türkçede başka bir anlama geliyormuş gibi görünse bile çevrilmez.\n")
        append("8. Açıklama, not veya tırnak ekleme.\n\n")
        append("ÇIKTI: sadece Türkçe çevirinin kendisi. Başka hiçbir şey yazma.")
    }

    /** Yapay zekâ çevirisi (Gemini). Başarısız olursa özel durum fırlatır. */
    fun ai(text: String, prev: String, prefs: Prefs): String {
        val key = prefs.apiKey
        require(key.isNotEmpty()) { "Anahtar yok" }
        val bk = "a|" + prefs.hard + "|" + text
        bellektenAl(bk)?.let { return it }
        val hints = Slang.hintsFor(text, prefs.hard)
        val user = buildString {
            // Araştırma: başlık/içerik bilgisi + önceki replikler kaliteyi
            // belirgin artırıyor.
            if (prefs.icerik.isNotEmpty())
                append("İZLENEN/OYNANAN: ").append(prefs.icerik).append("\n\n")
            if (prev.isNotEmpty())
                append("ÖNCEKİ REPLİKLER (bağlam, bunları çevirme):\n").append(prev).append("\n\n")
            val adlar = ozelAdlar(text)
            if (adlar.isNotEmpty())
                append("ÇEVİRME, OLDUĞU GİBİ YAZ (özel ad): ")
                    .append(adlar.joinToString(", ")).append("\n\n")
            append("ÇEVİRİLECEK: ").append(text)
            if (hints.isNotEmpty()) append("\n\nÖNERİLEN KARŞILIKLAR: ").append(hints.joinToString(" ; "))
            append("\n\nSadece çeviriyi yaz.")
        }

        fun govde(dusunmeKapali: Boolean): String {
            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt(prefs.hard)))))
                put("contents", JSONArray().put(JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", user)))))
                val gen = JSONObject()
                    .put("temperature", 0.7)
                    .put("maxOutputTokens", 160)
                    .put("candidateCount", 1)
                // Düşünme KAPALI: 3.x modelleri varsayılan olarak düşünüyor ve bir
                // altyazı repliği için saniyeler harcıyor.
                if (dusunmeKapali) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                put("generationConfig", gen)
                val safety = JSONArray()
                for (c in arrayOf("HARM_CATEGORY_HARASSMENT", "HARM_CATEGORY_HATE_SPEECH",
                    "HARM_CATEGORY_SEXUALLY_EXPLICIT", "HARM_CATEGORY_DANGEROUS_CONTENT")) {
                    safety.put(JSONObject().put("category", c).put("threshold", "BLOCK_NONE"))
                }
                put("safetySettings", safety)
            }
            return body.toString()
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
                prefs.model + ":generateContent?key=" + URLEncoder.encode(key, "UTF-8")

        // Bazı modeller thinkingConfig / candidateCount alanlarını kabul etmiyor
        // ve "Request contains an invalid argument" diyip 400 veriyor. Hata
        // metni alan adını söylemediği için SORUNUN ADINA BAKILMAZ: geçersiz
        // istek dönen her durumda sade gövdeyle bir kez daha denenir. Hangi
        // gövdenin çalıştığı akılda tutulur, sonraki replikler boşuna iki
        // istek atmaz.
        var raw = post(url, govde(dusunmeDestekli))
        if (dusunmeDestekli && gecersizIstek(raw)) {
            dusunmeDestekli = false
            raw = post(url, govde(false))
        }
        val j = JSONObject(raw)
        if (j.has("error")) {
            // Alan adını da al: "geçersiz istek" tek başına hangi alanın
            // reddedildiğini söylemiyor, kayıtta görünmesi gerekiyor.
            val e = j.getJSONObject("error")
            val mesaj = e.optString("message", "Çeviri hatası")
            val ayrinti = e.optJSONArray("details")?.toString()?.take(100) ?: ""
            throw RuntimeException(if (ayrinti.isEmpty()) mesaj else mesaj + " | " + ayrinti)
        }
        val cands = j.optJSONArray("candidates") ?: throw RuntimeException("Yanıt boş")
        if (cands.length() == 0) throw RuntimeException("Yanıt boş")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw RuntimeException("Yanıt boş")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val cikti = extractTr(sb.toString())
        bellegeKoy(bk, cikti)
        return cikti
    }

    /** Model gövdedeki bir alanı reddetti mi? */
    private fun gecersizIstek(raw: String): Boolean =
        raw.contains("INVALID_ARGUMENT") ||
        raw.contains("invalid argument", true) ||
        raw.contains("Unknown name") ||
        raw.contains("thinkingConfig") ||
        (raw.contains("\"error\"") && raw.contains("\"code\": 400"))

    private fun extractTr(s: String): String {
        var t = s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        // Model düz metin yazar; eski sürümlerden kalan JSON biçimi de kabul edilir.
        if (t.startsWith("{")) {
            try {
                val j = JSONObject(t).optString("tr", "").trim()
                if (j.isNotEmpty()) return j
            } catch (e: Exception) {
                val m = Regex("\"tr\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").find(t)
                if (m != null) return m.groupValues[1].replace("\\\"", "\"").replace("\\n", " ").trim()
            }
        }
        t = t.trim().trim('"').trim()
        if (t.length > 220) t = t.take(220)
        return t
    }

    @Volatile var deeplKarakter = 0
    @Volatile var deeplHata = ""

    /**
     * DeepL çevirisi.
     *
     * Ücretsiz Developer anahtarı ":fx" ile biter ve api-free ucunu kullanır;
     * ücretli anahtarlar normal uca gider. Kota dolunca (456) ya da anahtar
     * geçersizse (403) boş döner, çağıran Google ucuna düşer.
     *
     * DeepL'e metin OLDUĞU GİBİ gönderilir: deyimleri cihaz üstü motordan
     * çok daha iyi çözüyor, sadeleştirmeye ihtiyacı yok. Yumuşattığı küfür
     * Türkçe tarafta sertlestir ile geri sertleşir.
     */
    fun deepl(text: String, key: String): String {
        if (key.isBlank() || text.isBlank()) return ""
        val uc = if (key.trim().endsWith(":fx")) "https://api-free.deepl.com/v2/translate"
                 else "https://api.deepl.com/v2/translate"
        val govde = "text=" + URLEncoder.encode(text, "UTF-8") +
                "&source_lang=EN&target_lang=TR&split_sentences=0"
        val c = (URL(uc).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 4000
            readTimeout = 6000
            setRequestProperty("Authorization", "DeepL-Auth-Key " + key.trim())
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
        }
        OutputStreamWriter(c.outputStream, "UTF-8").use { it.write(govde) }
        val kod = try { c.responseCode } catch (e: Exception) { -1 }
        val raw = readAll(c)
        if (kod !in 200..299) {
            deeplHata = when (kod) {
                456 -> "kota doldu (aylık 500 bin karakter)"
                403 -> "anahtar geçersiz"
                429 -> "çok sık istek"
                else -> "hata " + kod
            }
            return ""
        }
        deeplHata = ""
        deeplKarakter += text.length
        val j = JSONObject(raw)
        val arr = j.optJSONArray("translations") ?: return ""
        if (arr.length() == 0) return ""
        return arr.getJSONObject(0).optString("text", "").trim()
    }

    /**
     * Hızlı motor: anahtarsız Google ucu. Üç adres sırayla denenir; biri
     * yanıt vermezse ya da hız sınırına takılırsa ötekine geçilir.
     * Süreler kısa: altyazı ekrandan gitmeden bir sonuç dönsün.
     * Argo sözlüğü burada da uygulanır, küfür sansürlenmez.
     */
    fun fast(text: String, hard: Int): String {
        // Jetonla koruma KALDIRILDI: Google cümleyi yeniden dizince jetonlar
        // yanlış yere düşüyor ve cümle anlamsızlaşıyordu. Artık düz çevrilir,
        // sonra Türkçe taraf sertleştirilir; böylece dilbilgisi bozulmuyor.
        val bk = "f|" + hard + "|" + text
        bellektenAl(bk)?.let { return it }
        val q = URLEncoder.encode(text, "UTF-8")
        val uclar = listOf(
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=tr&dt=t&q=$q",
            "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=en&tl=tr&dt=t&q=$q",
            "https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=en&tl=tr&q=$q"
        )
        for (u in uclar) {
            val out = try { parseGtx(get(u, 2500, 3500)) } catch (e: Exception) { null }
            if (!out.isNullOrBlank()) {
                val cikti = sertlestir(out.trim(), hard)
                bellegeKoy(bk, cikti)
                return cikti
            }
        }
        return ""
    }

    /**
     * Makine çevirisi küfrü kibarlaştırır ("kahretsin", "lanet olsun").
     * Türkçe tarafta geri sertleştirilir; cümle yapısına dokunulmaz.
     */
    private val KUFUR = Regex(
        "\\b(fuck\\w*|shit\\w*|bitch\\w*|cunt\\w*|motherfuck\\w*|asshole|bastard|" +
        "dick|cock|pussy|whore|slut|prick|damn|goddamn|piss\\w*|wank\\w*|bollocks|" +
        "nigga|hell|screw you|son of a bitch)\\b",
        RegexOption.IGNORE_CASE
    )

    /** Cümle başında da gelebilen, özel ad SAYILMAYACAK sık kelimeler. */
    private val SIK_BAS = setOf(
        "the","a","an","i","you","he","she","it","we","they","this","that","these","those",
        "what","where","when","why","how","who","yes","no","yeah","nah","ok","okay","hey","yo",
        "and","but","or","if","so","then","now","here","there","well","look","listen","come",
        "get","go","let","man","dude","bro","oh","ah","err","uh","um","my","your","his","her",
        "our","their","don","didn","can","will","just","like","all","right","good","bad","not",
        // Emir kipiyle başlayan cümleler ad sanılıyordu ("Put it on speakerphone").
        "put","take","give","tell","call","keep","stop","wait","hold","watch","move","open",
        "close","bring","leave","check","turn","pick","drop","send","make","find","help","show",
        "run","shut","say","try","use","want","need","talk","walk","sit","stand","stay","back",
        "down","out","up","off","over","why","what","who","how","never","nothing","something",
        "everybody","everyone","somebody","anyone","anybody","please","sorry","thanks","thank"
    )

    /**
     * Metindeki özel adları bulur (Boobie, Ray, Leonida...).
     *
     * Model küçük olduğu için "özel isimler çevrilmez" kuralı yetmiyordu:
     * "Boobie" adını "Mmeme" diye çevirdi. Adlar artık teker teker yazılıp
     * çevrilmemesi söyleniyor.
     */
    fun ozelAdlar(text: String): List<String> {
        val out = LinkedHashSet<String>()
        for (ham in text.split(Regex("[^A-Za-z'\\-]+"))) {
            val k = ham.trim('\'', '-')
            if (k.length < 3) continue
            if (!k[0].isUpperCase()) continue
            if (k.all { it.isUpperCase() }) continue          // BAĞIRAN YAZI, ad değil
            if (SIK_BAS.contains(k.lowercase())) continue
            out.add(k)
            if (out.size >= 6) break
        }
        return out.toList()
    }

    /** Satırda küfür var mı; Sade sınıfı buna göre Türkçe vurguyu ekler. */
    fun kufurVar(en: String): Boolean = KUFUR.containsMatchIn(en)

    private val SERT: Array<Triple<String, String, String>> = arrayOf(
        //            makinenin yazdığı     sokak ağzı            tam sansürsüz
        Triple("allah kahretsin", "hay sikeyim", "hay amına koyayım"),
        Triple("canın cehenneme", "siktir git", "siktir git amına koyayım"),
        Triple("lanet olsun", "hassiktir", "hay sikeyim"),
        Triple("kahretsin", "siktir", "siktir lan"),
        Triple("kahrolası", "lanet olası", "sikik"),
        Triple("kahrolsun", "siktirsin", "sikilsin"),
        Triple("piç kurusu", "orospu çocuğu", "orospu çocuğu"),
        Triple("aşağılık herif", "şerefsiz herif", "orospu çocuğu"),
        Triple("alçak herif", "şerefsiz", "orospu çocuğu"),
        Triple("salak herif", "gerizekâlı", "götoş"),
        Triple("aptal herif", "gerizekâlı", "götoş"),
        Triple("hergele", "şerefsiz", "puşt"),
        Triple("sürtük", "kaltak", "orospu"),
        Triple("fahişe", "kaltak", "orospu"),
        Triple("defol", "siktir git", "siktir ol git"),
        Triple("saçmalık", "zırva", "sikik saçmalık"),
        Triple("berbat", "boktan", "boktan"),
        Triple("umurumda değil", "sikimde değil", "sikimde bile değil"),
        Triple("umurumda bile değil", "sikimde değil", "sikimde bile değil"),
        Triple("hiç umursamıyorum", "sikimde değil", "sikimde bile değil"),
        Triple("aptal", "gerizekâlı", "gerizekâlı"),
        Triple("salak", "gerizekâlı", "götoş"),
        Triple("baş belası", "baş belası", "götüme batan")
    )

    /**
     * Makine çevirisi küfrü kibarlaştırıyor ("kahretsin", "lanet olsun").
     * Türkçe tarafta geri sertleştirilir; cümlenin dizilişine dokunulmaz.
     * Büyük/küçük harf kendiliğinden korunur.
     */
    fun sertlestir(tr: String, hard: Int): String {
        if (hard < 2) return tr
        var out = tr
        for ((bul, sokak, tam) in SERT) {
            val yeni = if (hard >= 3) tam else sokak
            var idx = out.indexOf(bul, 0, true)
            while (idx >= 0) {
                val bulunan = out.substring(idx, idx + bul.length)
                val buyuk = bulunan[0].isUpperCase()
                val yerine = if (buyuk) yeni.replaceFirstChar { it.uppercaseChar() } else yeni
                out = out.substring(0, idx) + yerine + out.substring(idx + bul.length)
                idx = out.indexOf(bul, idx + yerine.length, true)
            }
        }
        return out
    }

    /** İki yanıt biçimi var: [[["çeviri",...],...],...] ve yedek uçtaki ["çeviri"]. */
    private fun parseGtx(json: String): String? {
        if (json.isBlank()) return null
        val root = JSONArray(json)
        val sentences = root.optJSONArray(0)
        val text = if (sentences != null) {
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.optJSONArray(i)?.optString(0, "") ?: ""
                if (part.isNotEmpty() && part != "null") sb.append(part)
            }
            sb.toString().trim()
        } else {
            (root.opt(0) as? String)?.trim() ?: ""
        }
        if (text.isEmpty()) return null
        return android.text.Html.fromHtml(text, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
    }

    private fun post(url: String, body: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15000
            readTimeout = 25000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        OutputStreamWriter(c.outputStream, "UTF-8").use { it.write(body) }
        return readAll(c)
    }

    private fun get(url: String, connectMs: Int = 8000, readMs: Int = 12000): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = connectMs
            readTimeout = readMs
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            )
        }
        return readAll(c)
    }

    /**
     * disconnect() ÇAĞRILMIYOR. Çağrıldığında soket kapanıyor ve bir sonraki
     * replikte TCP+TLS el sıkışması sıfırdan kuruluyordu: her satırda 200-400 ms
     * kayıp. Akış sonuna kadar okunduğu için bağlantı havuzda kalır ve
     * sonraki istek aynı soketi kullanır.
     */
    private fun readAll(c: HttpURLConnection): String {
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return BufferedReader(InputStreamReader(stream ?: return "", "UTF-8")).use { it.readText() }
    }

    /**
     * Bağlantıyı ısıtır: Başlat'a basıldığında el sıkışması şimdi yapılır,
     * ilk replik beklemez. Hata önemsizdir, sessizce yutulur.
     */
    fun isit(key: String) {
        try { get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=tr&dt=t&q=ok", 2000, 2500) } catch (e: Throwable) { }
        if (key.isNotEmpty()) {
            try {
                get("https://generativelanguage.googleapis.com/v1beta/models?key=" +
                        URLEncoder.encode(key, "UTF-8"), 2500, 3000)
            } catch (e: Throwable) { }
        }
    }
}
