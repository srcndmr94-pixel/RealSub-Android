package com.realsub.app

/**
 * Yarım kalmış altyazı için kısa, sınırlı bekleme.
 *
 * GameLingo'nun SubtitleHoldPolicy kuralının aynısı: cümle noktalamayla
 * bitmişse HİÇ beklenmez; virgülle, tire ile ya da bağlaçla bitmişse
 * (yani devamı gelecekse) yalnızca 140 ms beklenir.
 *
 * Benim v19'da koyduğum "her değişimden sonra bekle" yaklaşımı yanlıştı:
 * bütün replikleri geciktiriyor ve yarısını kaçırıyordu.
 */
object Bekleme {

    private const val MS = 140L

    private val yarimKelime = Regex(
        "(?i)\\b(?:and|or|if|because|the|a|to|of|is|are|was|were|will|would|" +
            "could|should|can|with|when|that|as|not|but|so|for|in|on|at|my|your)\\s*$"
    )

    private val olumsuzFiil = Regex(
        "(?i)\\b(?:will|would|shall|can|could|must)\\s+not\\b[^.!?]{1,120},\\s*[a-z]+$"
    )

    fun ms(kaynak: String): Long {
        val s = kaynak.trim()
        if (s.length < 5 || s.length > 200) return 0L
        if (s.startsWith("[") && s.endsWith("]")) return 0L      // sahne notu
        val son = s.last()
        if (son == '.' || son == '!' || son == '?' || son == '…') return 0L
        if (son == ',' || son == '—' || son == '-') return MS
        if (yarimKelime.containsMatchIn(s) || olumsuzFiil.containsMatchIn(s)) return MS
        return 0L
    }
}
