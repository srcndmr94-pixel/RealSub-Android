package com.realsub.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** Her uygulamanın üstünde duran altyazı katmanı. */
class Overlay(private val ctx: Context, private val prefs: Prefs) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: View? = null
    private var tvTr: TextView? = null
    private var tvEn: TextView? = null

    /** Bulunan altyazının ekrandaki üst ve alt kenarı (piksel); 0 ise bilinmiyor. */
    @Volatile var anchorTop = 0
    @Volatile var anchorBottom = 0

    fun show() {
        if (root != null) return
        val v = LayoutInflater.from(ctx).inflate(R.layout.overlay, null)
        tvTr = v.findViewById(R.id.ovTr)
        tvEn = v.findViewById(R.id.ovEn)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = bottomPx()

        applyStyle()
        try {
            wm.addView(v, lp)
            root = v
        } catch (e: Exception) {
            root = null
        }
    }

    /**
     * Katmanın ekranın altından yüksekliği.
     * cover: bulunan altyazının tam üstüne oturur (onu örter)
     * above: bulunan altyazının hemen üstünde durur
     * fixed: ayardaki sabit yükseklik
     */
    private fun bottomPx(): Int {
        val dm = ctx.resources.displayMetrics
        val h = dm.heightPixels
        val yer = prefs.placement
        if (yer == "fixed" || (anchorTop <= 0 && anchorBottom <= 0)) {
            return (h * prefs.bottomPct / 100f).toInt()
        }
        return if (yer == "cover") {
            // Alt kenarı, okunan yazının alt kenarına denk gelsin.
            val alt = if (anchorBottom > 0) anchorBottom else anchorTop
            (h - alt).coerceIn(0, (h * 0.9f).toInt())
        } else {
            val ust = if (anchorTop > 0) anchorTop else anchorBottom
            ((h - ust) + h * 0.012f).toInt().coerceIn(0, (h * 0.9f).toInt())
        }
    }

    fun reposition() {
        val v = root ?: return
        try {
            val lp = v.layoutParams as WindowManager.LayoutParams
            lp.y = bottomPx()
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) { }
    }

    private fun zemin(): GradientDrawable {
        val a = (prefs.bgOpacity * 255 / 100).coerceIn(0, 255)
        return GradientDrawable().apply {
            cornerRadius = 10f * ctx.resources.displayMetrics.density
            setColor(Color.argb(a, 0, 0, 0))
        }
    }

    private fun applyStyle() {
        val renk = if (prefs.textColor == "yellow") Color.parseColor("#FFE600") else Color.WHITE
        val boyut = prefs.textSize
        tvTr?.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, boyut)
            setTextColor(renk)
            setTypeface(typeface, if (prefs.bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            background = zemin()
            val yatay = (14 * ctx.resources.displayMetrics.density).toInt()
            val dikey = (6 * ctx.resources.displayMetrics.density).toInt()
            setPadding(yatay, dikey, yatay, dikey)
        }
        tvEn?.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, boyut * 0.62f)
            background = zemin()
            val yatay = (10 * ctx.resources.displayMetrics.density).toInt()
            val dikey = (3 * ctx.resources.displayMetrics.density).toInt()
            setPadding(yatay, dikey, yatay, dikey)
        }
    }

    /** Ana iş parçacığından çağrılır. */
    fun set(tr: String, en: String) {
        applyStyle()
        reposition()
        tvTr?.text = tr
        tvTr?.visibility = if (tr.isEmpty()) View.GONE else View.VISIBLE
        val showEn = prefs.showEn && en.isNotEmpty()
        tvEn?.text = if (showEn) en else ""
        tvEn?.visibility = if (showEn) View.VISIBLE else View.GONE
    }

    /** Tanı satırı: küçük, soluk; altyazı yerine neden bir şey olmadığını yazar. */
    fun setNote(note: String) {
        applyStyle()
        reposition()
        tvTr?.visibility = View.GONE
        tvEn?.text = note
        tvEn?.visibility = if (note.isEmpty()) View.GONE else View.VISIBLE
    }

    fun hide() {
        val v = root ?: return
        try { wm.removeView(v) } catch (e: Exception) { }
        root = null
        tvTr = null
        tvEn = null
    }
}
