package com.realsub.app

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/**
 * Telefonun içinde çalışan çeviri modeli (Gemma).
 * İnternet, anahtar ve kota gerektirmez; model dosyası kullanıcı tarafından
 * bir kez telefona konur ve ayarlardan seçilir.
 *
 * Model yoksa ya da yüklenemezse her şey sessizce boş döner; çağıran
 * taraf hızlı motora düşer. Yani bu dosya hiçbir koşulda uygulamayı kırmaz.
 */
object LocalModel {

    @Volatile private var llm: LlmInference? = null
    @Volatile private var loadedPath: String = ""
    @Volatile var lastError: String = ""
        private set

    /** Model hazır mı? */
    val ready: Boolean get() = llm != null

    /** Ayarlardaki yol değiştiyse yeniden yükler. Arka plandan çağrılır, uzun sürebilir. */
    @Synchronized
    fun ensure(ctx: Context, path: String): Boolean {
        if (path.isBlank()) { close(); return false }
        if (llm != null && loadedPath == path) return true
        close()
        return try {
            val file = java.io.File(path)
            if (!file.exists() || file.length() < 1_000_000L) {
                lastError = "Model dosyası bulunamadı"
                false
            } else {
                val options = LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(path)
                    .setMaxTokens(512)
                    .build()
                llm = LlmInference.createFromOptions(ctx, options)
                loadedPath = path
                lastError = ""
                true
            }
        } catch (e: Throwable) {
            lastError = (e.message ?: e.javaClass.simpleName).take(160)
            llm = null
            loadedPath = ""
            false
        }
    }

    @Synchronized
    fun close() {
        try { llm?.close() } catch (e: Throwable) { }
        llm = null
        loadedPath = ""
    }

    private fun prompt(text: String, hard: Int): String {
        val kural = when (hard.coerceIn(0, 3)) {
            0 -> "Küfürleri yumuşat."
            1 -> "Doğal konuşma dili kullan, küfrü ölçülü ver."
            2 -> "Sokak ağzı kullan. Küfür ve argoyu yumuşatma, olduğu gibi çevir."
            else -> "Hiçbir şeyi yumuşatma; en sert ve doğrudan karşılığı kullan."
        }
        return "Aşağıdaki İngilizce altyazıyı Türkçeye çevir. $kural " +
                "Kelimesi kelimesine değil, Türkçe konuşan biri nasıl söylerse öyle çevir. " +
                "Açıklama ekleme, sadece çeviriyi yaz.\n\n$text\n\nÇeviri:"
    }

    /** Çeviri. Model yoksa ya da hata olursa boş döner. */
    fun translate(text: String, hard: Int): String {
        val engine = llm ?: return ""
        return try {
            val out = engine.generateResponse(prompt(text, hard)) ?: ""
            out.trim()
                .removePrefix("Çeviri:").trim()
                .lines().firstOrNull { it.isNotBlank() }?.trim()
                ?.trim('"', '«', '»') ?: ""
        } catch (e: Throwable) {
            lastError = (e.message ?: e.javaClass.simpleName).take(160)
            ""
        }
    }
}
