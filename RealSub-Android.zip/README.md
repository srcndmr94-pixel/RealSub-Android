# RealSub (Android)

Ekrandaki İngilizce altyazıyı okur, **sokak ağzına ve küfre sadık** Türkçesini ekranın üstünde gösterir.
Hangi uygulamayı kullandığın fark etmez: YouTube, oyun, yerel oynatıcı — altyazı her şeyin üstünde durur.

## Nasıl çalışır

1. Ekran kaydı izniyle ekranın görüntüsü alınır (hiçbir yere gönderilmez, kayıt tutulmaz).
2. Yalnızca senin seçtiğin **altyazı alanı** kesilip okunur.
3. Okuma cihazın içinde yapılır (ML Kit) — internet gerekmez, ücretsizdir.
   Altyazının ekranda nerede olduğunu program kendisi bulur: alt yarıdaki metin blokları çıkarılır,
   oynatıcı arayüzü (süre, "Diğer videolar", öneri kartları) elenir, ortaya yakın duran blok altyazı sayılır.
4. Metin değiştiğinde, yalnızca o zaman çeviri istenir. Sahnedeki hareket istek tetiklemez.
5. Çeviri, bulunan altyazının **hemen üstünde** gösterilir; oyunun kendi altyazısını kapatmaz.

## Kurulum

1. GitHub'da **Actions** sekmesinden son çalışmayı aç.
2. **Artifacts** bölümünden `RealSub-APK` dosyasını indir, içinden `app-debug.apk` çıkar.
3. Telefona kur ("bilinmeyen kaynak" uyarısına izin ver).
4. Uygulamayı aç:
   - **Ekranın üstüne çizme iznini ver** — zorunlu.
   - **API anahtarı** — Google AI Studio'dan ücretsiz alınır. Boş bırakırsan ücretsiz motor kullanılır.
   - **Altyazı yakalama** — varsayılan olarak otomatik; elle alan seçmen gerekmez.
     Program bulamazsa bu kutunun işaretini kaldırıp alanı elle seçebilirsin.
   - **Başlat** — ekran kaydı iznini onayla, uygulamadan çık, izlemeye başla.
5. Durdurmak için bildirime dokun.

## Bir şey görünmüyorsa

Uygulamadaki **5. Durum** bölümü akışın neresinde takıldığını söyler. Çalışırken uygulamaya dön,
**Tek kare oku** → **Durumu yenile**:

| Gördüğün | Anlamı |
|---|---|
| Alınan kare 0 | Ekran kaydı başlamamış; Başlat'a tekrar bas |
| Parlak nokta çok düşük | Seçili alan yanlış yerde ya da altyazı o anda ekranda değil |
| Okuma denemesi var, "son okunan: (okunamadı)" | Alan doğru ama yazı küçük/bulanık; alanı daha dar seç |
| Son okunan dolu, son çeviri boş | Okuma çalışıyor, çeviri takılıyor — "son hata" satırına bak |

## Çeviri nasıl akıyor

Ekranda yeni bir replik görülür görülmez iki aşama çalışır:

1. **Taslak** — telefonda model varsa onunla, yoksa anahtarsız hızlı motorla. Hızlı motor üç ayrı Google ucunu
   sırayla dener (biri yanıt vermezse ötekine geçer) ve süreleri kısa tutar; yarım saniyede ekrana düşer.
   Argo sözlüğü burada da uygulanır, küfür sansürlenmez.
2. **Düzeltme** — anahtar girilmişse yapay zekâ aynı repliği bağlamıyla birlikte daha doğal bir Türkçeyle
   çevirir ve taslağın yerine geçer. Bu arada yeni replik geldiyse eski çeviri ekrana yazılmaz.

Yani anahtar olmadan da anında çeviri görürsün; anahtarla birlikte bir saniye sonra akıcı hâline döner.

## Cihaz üstü model (isteğe bağlı)

Telefonda çalışan bir Gemma modeli kurarsan taslak çeviri **internetsiz, anahtarsız ve kotasız** yapılır.

1. Bilgisayarda MediaPipe uyumlu bir Gemma modeli indir (`.task` ya da `.litertlm`).
   Uç cihaz için olanlar: E2B (~1,5 GB) veya E4B (~3 GB).
2. Dosyayı telefona kopyala.
3. Uygulamada **Cihaz üstü model → Model dosyasını seç** ile göster. Uygulama dosyayı kendi alanına kopyalar;
   telefonda o kadar boş yer gerekir.
4. **Başlat**'a bastığında model arka planda yüklenir, ilk replikte devreye girer.

Durum ekranındaki **Çeviren** satırı hangi motorun çevirdiğini söyler.

Not: Cihaz üstü modeller üst seviye telefonlar için ayarlanmış; eski cihazlarda yavaş çalışır ya da hiç yüklenmez.
Yüklenmezse uygulama sessizce hızlı motora düşer, bir şey bozulmaz.

## Sertlik seviyeleri

| Seviye | Örnek: *"Fuck you, bitch."* |
|---|---|
| Yumuşak | Canın cehenneme, cadaloz. |
| Doğal | Defol, sürtük. |
| **Sokak ağzı** (varsayılan) | Siktir git, kaltak. |
| Tam sansürsüz | Siktir git amına koyayım, orospu. |

Yerleşik sözlük hem ücretsiz motorda doğrudan uygulanır, hem yapay zekâya kural olarak verilir.

## Bilinen sınırlar

- **Netflix, Disney+ gibi uygulamalar** ekran kaydını engeller (FLAG_SECURE); o uygulamalarda kare siyah gelir ve okuma yapılamaz. Bu Android'in kuralı, aşılamaz.
- Her yeni altyazı satırı bir çeviri isteğidir. Ücretsiz Gemini kotasında dakikalık sınır vardır.
- Okuma cihaz üstünde yapıldığı için altyazı küçük ya da çok süslü yazı tipindeyse hata payı artar.

## Derleme

GitHub Actions her `main` push'unda APK üretir: `.github/workflows/build.yml`.
Bilgisayarda derlemek istersen: Android Studio ile aç, `:app:assembleDebug`.

## Yapı

| Dosya | İşi |
|---|---|
| `MainActivity.kt` | Ayar ekranı, izinler, başlat/durdur |
| `RegionActivity.kt` | Altyazı alanını parmakla seçme |
| `CaptureService.kt` | Ekran kaydı, değişim algılama, akışın yönetimi |
| `Ocr.kt` | Cihaz içi metin okuma ve temizleme |
| `Translator.kt` | Gemini çevirisi + ücretsiz motor |
| `Slang.kt` | Sokak ağzı sözlüğü, dört sertlik seviyesi |
| `Overlay.kt` | Ekranın üstündeki altyazı katmanı |
| `Prefs.kt` | Ayarların saklanması |
